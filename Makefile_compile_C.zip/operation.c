#include"operation.h"

int sum(int a, int b){
    return a+ b;
}

int minus(int a, int b){
    return a-b;
}

int mul(int a, int b){
    return a*b;
}

int div_(int a, int b){
    return a/b;
}

int mod(int a, int b){
    return a%b;
}