#include"array.h"

int main(){
    int n = 100;
    int *a = (int*)malloc(n*sizeof(int));

    randomArray(a, n);
    sortArray(a, n);
    printArray(a, n);

    return 0;
}