#ifndef MAX_NUMBER
#define MAX_NUMBER 10000
#endif

#ifndef __STDIO_H__
#define __STDIO_H__
#include <stdio.h>
#endif
#ifndef __MALLOC_H__
#define __MALLOC_H__
#include<malloc.h>
#endif
#ifndef __TIME_H__
#define __TIME_H__
#include<time.h>
#endif
#ifndef __STDLIB_H__
#define __STDLIB_H__
#include<stdlib.h>
#endif


#ifndef __MATRIX_H__
#define __MATRIX_H__

int** matrix_Multi(int **a, int na, int ma, int **b, int nb, int mb);
int print_Matrix(int **a, int n, int m);
int** random_Matrix(int **a, int n, int m);

void matrix_Multi_s(int *a[], int na, int ma, int *b[], int nb, int mb);
void print_Matrix_s(int *a[], int n, int m);
void random_Matrix_s(int *a[], int n, int m);

#endif