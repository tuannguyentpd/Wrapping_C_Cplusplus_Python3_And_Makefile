#ifndef MAX_NUMBER
#define MAX_NUMBER 10000
#endif

#ifndef __STDIO_H__
#define __STDIO_H__
#include <stdio.h>
#endif
#ifndef __MALLOC_H__
#define __MALLOC_H__
#include<malloc.h>
#endif
#ifndef __TIME_H__
#define __TIME_H__
#include<time.h>
#endif
#ifndef __STDLIB_H__
#define __STDLIB_H__
#include<stdlib.h>
#endif


#ifndef __ARRAY_H__
#define __ARRAY_H__

void sortArray(int *a, int n);
void printArray(int *a, int n);
void randomArray(int *a, int n);

#endif