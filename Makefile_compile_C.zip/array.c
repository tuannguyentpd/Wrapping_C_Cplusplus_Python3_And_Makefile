#include"array.h"

void sortArray(int *a, int n){
    if (n<2) return;
    int temp;
    for (int i=0;i<n-1;++i){
        for (int j=i+1;j<n;++j){
            if (a[i]>a[j]){
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }
}

void printArray(int *a, int n){
    for (int i=0;i<n;++i){
        printf("%d\t", a[i]);
    }
    printf("\n");
}

void randomArray(int *a, int n){
    srand(time(NULL));
    for (int i=0;i<n;++i){
        a[i] = rand()%MAX_NUMBER;
    }
}