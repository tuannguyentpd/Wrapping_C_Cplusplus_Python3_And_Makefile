#include "lib.h"
#include "allocal.h"
#include "generateArray.h"
#include "arraySupport.h"

int main(){
    int *a, n;
    n = 10;
    
    a = (int*)malloc(n * sizeof(int));
    //allocal_array(a, n);
    generate_array(a, n);
    print_array(a, n);
    free_array(a);

    return 0;
}