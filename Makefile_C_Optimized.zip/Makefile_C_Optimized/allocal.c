#include"allocal.h"

void allocal_array(int *a, int n){
    if (a == NULL){
        a = (int *)malloc(n*sizeof(int));
    }
}

void free_array(int *a){
    free(a);
}
