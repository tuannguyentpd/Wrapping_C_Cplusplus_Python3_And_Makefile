#ifndef __MALLOC_H__
#define __MALLOC_H__
#include<malloc.h>
#endif

#ifndef __ALLOCAL_H__
#define __ALLOCAL_H__

void allocal_array(int *a, int n);
void free_array(int *a);

#endif