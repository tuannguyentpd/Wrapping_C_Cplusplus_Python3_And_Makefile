import numpy as np
import matplotlib.pyplot as plt
import random

MAX_NUM = 3000

def generateData(n):
    return np.random.randint(MAX_NUM, size=(n, )) - np.random.randint(MAX_NUM, size=(n, ))\
        , np.random.randint(MAX_NUM, size=(n, )) - np.random.randint(MAX_NUM, size=(n, )),\
             np.random.randint(MAX_NUM, size=(n, )) - np.random.randint(MAX_NUM, size=(n, ))

from mpl_toolkits.mplot3d import Axes3D
def visualizeData(x_, y_, z_):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    
    ax.scatter3D(x_, y_, z_, marker='o', cmap='Greens');
    
    plt.show()

if __name__=='__main__':
    x_, y_, z_ = generateData(1000)
    #print(x_)
    #print(y_)
    #print(z_)
    
    visualizeData(x_, y_, z_)