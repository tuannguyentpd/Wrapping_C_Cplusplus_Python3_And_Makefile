#include "../Headers/OpencvHeaders.h"


#ifndef __LAB01_H__
#define __LAB01_H__

using namespace std;
using namespace cv;

/*Hàm kiểm tra ma trận ảnh có phải là ảnh trắng đen hay không
  Tham số: Ma trận điểm ảnh cần kiểm tra
  Trả về: false nếu là ảnh màu, true nếu là ảnh trắng đen
*/
bool isGrayscaleImage(Mat image);

/*Hàm chuyển đổi ảnh màu sang trắng đen
  Tham số: Ma trận điểm ảnh cần chuyển đổi, tỷ lệ màu R,G,B khi tiến hành chuyển (ở đây mặc định các tham số này dựa trên luminosity method)
  Trả về: Ma trận ảnh đã chuyển đổi
*/
Mat convertToGrayScaleImage(const Mat origin, float redScale = 0.3, float greenScale = 0.59, float blueScale = 0.11);

/*Hàm chuyển đổi ảnh sang ảnh mới có độ sáng thay đổi
  Tham số: Ma trận điểm ảnh cần chuyển đổi, độ sáng cần thay đổi ( lớn hơn 0 khi muốn tăng độ sáng, nhỏ hơn 0 nếu muốn giảm)
  Trả về: Ma trận ảnh đã chuyển đổi
*/
Mat adjustBrightness(const Mat origin, int b);

/*Hàm chuyển đổi ảnh sang ảnh mới có độ tương phản thay đổi
  Tham số: Ma trận điểm ảnh cần chuyển đổi, độ tương phản cần thay đổi ( lớn hơn 0 khi muốn tăng độ tương phản, nhỏ hơn 0 nếu muốn giảm)
  Trả về: Ma trận ảnh đã chuyển đổi
*/
Mat adjustConstrast(const Mat origin, float c);

/*Hàm chuyển đổi ảnh màu sang âm bản
  Tham số: Ma trận điểm ảnh cần chuyển đổi
  Trả về: Ma trận ảnh đã chuyển đổi
*/
Mat convertToNegativeImage(const Mat origin, float redScale = 0.3, float greenScale = 0.59, float blueScale = 0.11);

/*Hàm chuyển đổi ảnh sang ảnh mới bằng phương pháp sử dụng mũ gamma
  Tham số: Ma trận điểm ảnh cần chuyển đổi, hệ số mũ gamma, hệ số cân chỉnh trong phép biến đổi 
  Trả về: Ma trận ảnh đã chuyển đổi
*/
Mat gammaCorrection(const Mat origin, float gamma, float a = 1);

/*Hàm chuyển đổi ảnh sang ảnh mới bằng phương pháp sử dụng logarithm
  Tham số: Ma trận điểm ảnh cần chuyển đổi, hệ số cân chỉnh trong phép biến đổi
  Trả về: Ma trận ảnh đã chuyển đổi
*/
Mat LogarithmOperator(const Mat origin, float a = 0);

#endif // !__LAB01_H__