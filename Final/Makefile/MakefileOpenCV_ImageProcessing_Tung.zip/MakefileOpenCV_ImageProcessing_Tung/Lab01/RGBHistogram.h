#include "Lab01.h"

#ifndef __RGB_HISTOGRAM_H__
#define __RGB_HISTOGRAM_H__

class RGB_Histogram {
public:
	int numberBin;
	vector<int> r_hist;
	vector<int> g_hist;
	vector<int> b_hist;
	float r_mean, g_mean, b_mean, r_variant, g_variant, b_variant;
	//Mat temp;
public:
	RGB_Histogram();

	/*Hàm khởi tạo cho class Histogram
	  Tham số: Ma trận điểm ảnh cần tính, số bin màu cần tạo ra cho mỗi kênh màu
	*/
	RGB_Histogram(const Mat image, int numberBins=256);

	/*Hàm chuyển đổi histogram sang ma trận hình ảnh biểu diễn histogram
	Tham số: chiều rộng của ảnh, chiều cao của ảnh
	Trả về: Ma trận ảnh
	*/
	Mat drawHistogramToAnImage(int width = 550, int height = 400) ;

	/*Hàm so sánh 2 histogram dựa trên độ đo Pearson correlation coefficient
	Tham số: Histogram cần được so sánh với histogram này
	Trả về: giá trị độ tương đồng -1 đến 1 (1: giống nhau hoàn toàn, 0: không giống, -1: trái ngược nhau)
	*/
	float compare(RGB_Histogram other);
};

#endif // !__RGB_HISTOGRAM_H__