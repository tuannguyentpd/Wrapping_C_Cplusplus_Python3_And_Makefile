﻿#include "Lab01.h"

using namespace std;
using namespace cv;


bool isGrayscaleImage(Mat image) {
	bool ans = true;
	for (int y = 0; y < image.rows; y++) {
		for (int x = 0; x < image.cols; x++) {						//truy cập từng điểm ảnh trong ma trận
			if (image.at<Vec3b>(y, x)[0] != image.at<Vec3b>(y, x)[1] || image.at<Vec3b>(y, x)[0] != image.at<Vec3b>(y, x)[2]) { //kiểm tra xem các điểm màu có bằng nhau không nếu khác thì cho biến kết quả là false và trả về
				ans = false;
				break;
			}
		}
		if (!ans)
			break;
	}
	return ans;
}

Mat convertToGrayScaleImage(const Mat origin, float redScale, float greenScale, float blueScale) {
	float gray;
	Mat answer;
	answer = origin.clone();
	for (int y = 0; y < origin.rows; y++)
		for (int x = 0; x < origin.cols; x++) {						//truy cập từng điểm ảnh trong ma trận
			gray = origin.at<Vec3b>(y, x)[0] * redScale + origin.at<Vec3b>(y, x)[1] * greenScale + origin.at<Vec3b>(y, x)[2] * blueScale;		//tính mức xám cho từng bộ điểm màu trong điểm ảnh đó
			for (int color = 0; color < 3; color++)
				answer.at<Vec3b>(y, x)[color] = (uchar)gray;		//áp mức xám vừa tính cho cả ba điểm màu R,G,B
		}
	return answer;
}

Mat adjustBrightness(const Mat origin, int b) {
	Mat answer;
	answer = origin.clone();
	for (int y = 0; y < origin.rows; y++)
		for (int x = 0; x < origin.cols; x++) {
			for (int color = 0; color < 3; color++)						//truy cập từng điểm ảnh trong ma trận, từng điểm màu R,G,B
				answer.at<Vec3b>(y, x)[color] = saturate_cast<uchar>(origin.at<Vec3b>(y, x)[color] + b);		//tiến hành cộng từng điểm màu cho giá trị độ sáng cần thay đổi
		}
	return answer;
}

Mat adjustConstrast(const Mat origin, float c) {
	Mat answer;
	answer = origin.clone();
	int temp;
	for (int y = 0; y < origin.rows; y++)
		for (int x = 0; x < origin.cols; x++) {
			for (int color = 0; color < 3; color++) {						//truy cập từng điểm ảnh trong ma trận, từng điểm màu R,G,B
				answer.at<Vec3b>(y, x)[color] = saturate_cast<uchar>(origin.at<Vec3b>(y, x)[color] * c);//tiến hành nhân từng điểm màu cho giá trị độ tương phản cần thay đổi
			}

		}
	return answer;
}

Mat convertToNegativeImage(const Mat origin, float redScale, float greenScale, float blueScale) {
	Mat answer;
	answer = origin.clone();
	for (int y = 0; y < origin.rows; y++)
		for (int x = 0; x < origin.cols; x++) {						//truy cập từng điểm ảnh trong ma trận
			for (int color = 0; color < 3; color++)
				answer.at<Vec3b>(y, x)[color] = (uchar)(255 - answer.at<Vec3b>(y, x)[color]);		//chuyển sang điểm màu âm bản bằng cách lấy 255 trừ đi điểm màu đó
		}
	return answer;
}

Mat gammaCorrection(const Mat origin, float gamma, float a) {
	Mat answer;
	answer = origin.clone();
	int temp;
	for (int y = 0; y < origin.rows; y++)
		for (int x = 0; x < origin.cols; x++) {
			for (int color = 0; color < 3; color++) {						//truy cập từng điểm ảnh trong ma trận, từng điểm màu R,G,B
				answer.at<Vec3b>(y, x)[color] = saturate_cast<uchar>(a * 255 * pow(float(origin.at<Vec3b>(y, x)[color]) / 255, gamma));//tiến hành nhân hệ số cho từng điểm mà mũ gamma
			}

		}
	return answer;
}

Mat LogarithmOperator(const Mat origin, float a) {
	Mat answer;
	answer = origin.clone();
	int temp, max = 0;										//nếu hệ số là mặc định thì tự tính toán hệ số cho hàm
	if (a == 0) {
		for (int y = 0; y < origin.rows; y++)
			for (int x = 0; x < origin.cols; x++) {
				for (int color = 0; color < 3; color++) {					
					if (origin.at<Vec3b>(y, x)[color] > max)
						max = origin.at<Vec3b>(y, x)[color];		//tìm giá trị max của ma trận điểm ảnh
				}

			}
		a = 255 / log(1 + max);										//tính giá trị hệ số
	}
	for (int y = 0; y < origin.rows; y++)
		for (int x = 0; x < origin.cols; x++) {
			for (int color = 0; color < 3; color++) {						//truy cập từng điểm ảnh trong ma trận, từng điểm màu R,G,B
				answer.at<Vec3b>(y, x)[color] = (uchar)a*log(1 + origin.at<Vec3b>(y, x)[color]);	//tính giá trị cho từng điểm màu dựa trên hàm logarithm
			}

		}
	return answer;
}

/*
#define NUMBER_COMMAND 12
int main(int agrc, char** agrv) {
	if (agrc <= 1)
		return -1;
	string windowName1 = "Origin Image", windowName2 = "Edited Image", windowName3="HistogramImage1", windowName4="HistogramImage2";
	string commandList[NUMBER_COMMAND] = { "--g","--b","--c","--n","--lt","--gt","--hi","--cmphi","--hiqc","--hiqg","--cphiqc","--cphiqg" };			//những lệnh hỗ trợ
	Mat originImage1, originImage2, editedImage1, editedImage2;			//(1) khởi tạo đối tượng Matrix để xử lý dữ liệu ảnh dưới dạng các ma trận điểm ảnh
	int command;
	RGB_Histogram hist1, hist2;



	for (command = 0; command < NUMBER_COMMAND; command++) {								//tiến hành việc kiểm tra lệnh người dùng nhập vào
		if (strcmp(commandList[command].c_str(), strlwr(agrv[1])) == 0)
			break;
	}
	originImage1 = imread(agrv[2], IMREAD_COLOR);		//(2) hàm imread tiến hành đọc một file ảnh với đường dẫn được nhập vào từ command line và trả về ảnh đó dưới dạng ma trận điểm ảnh Mat
	
	if (!originImage1.data)
	{
		cout << "Can't open the image" << endl;
		return -1;
	}

	if (agrc < 3) {
		cout << "Please input command!" << endl;
		return -1;
	}

	
	switch (command) {								//xử lý các lệnh nhập vào
	case 0:
		if (isGrayscaleImage(originImage1)) {
			cout << "This function is only use for color image!" << endl;
		}
		editedImage1 = convertToGrayScaleImage(originImage1);
		break;
	case 1: 
		editedImage1 = adjustBrightness(originImage1, atoi(agrv[3])); break;
	case 2: 
		editedImage1 = adjustConstrast(originImage1, atof(agrv[3])); break;
	case 3:
		editedImage1 = convertToNegativeImage(originImage1);
		break;
	case 4:
		editedImage1 = LogarithmOperator(originImage1,atof(agrv[3])); break;
	case 5:
		editedImage1 = gammaCorrection(originImage1,atof(agrv[3]),atof(agrv[4])); break;
	case 6:
		hist1=RGB_Histogram(originImage1);
		editedImage1 = hist1.drawHistogramToAnImage();
		break;
	case 7:
		originImage2 = imread(agrv[3], IMREAD_COLOR);
		hist1 = RGB_Histogram(originImage1);
		hist2 = RGB_Histogram(originImage2);
		editedImage1 = hist1.drawHistogramToAnImage();
		editedImage2 = hist2.drawHistogramToAnImage();
		cout << hist1.compare(hist2);
		break;
	case 8:
		hist1 = RGB_Histogram(originImage1, atoi(agrv[3]));
		editedImage1 = hist1.drawHistogramToAnImage();
		break;
	case 9:
		hist1 = RGB_Histogram(originImage1, atoi(agrv[3]));
		editedImage1 = hist1.drawHistogramToAnImage();
		break;
	case 10:
		originImage2 = imread(agrv[3], IMREAD_COLOR);
		hist1 = RGB_Histogram(originImage1,atoi(agrv[4]));
		hist2 = RGB_Histogram(originImage2,atoi(agrv[4]));
		editedImage1 = hist1.drawHistogramToAnImage();
		editedImage2 = hist2.drawHistogramToAnImage();
		cout << hist1.compare(hist2);
		break;
	case 11:
		originImage2 = imread(agrv[3], IMREAD_COLOR);
		hist1 = RGB_Histogram(originImage1, atoi(agrv[4]));
		hist2 = RGB_Histogram(originImage2, atoi(agrv[4]));
		editedImage1 = hist1.drawHistogramToAnImage();
		editedImage2 = hist2.drawHistogramToAnImage();
		cout << hist1.compare(hist2);
		break;

	default: cout << "Please input right command!" << endl; return -1;
	}

	switch (command) {								//tiến hành show kết quả dựa trên lệnh
	case 0: case 1: case 2:case 3:case 4:case 5:
		namedWindow(windowName1, WINDOW_AUTOSIZE);
		namedWindow(windowName2, WINDOW_AUTOSIZE);
		imshow(windowName1, originImage1);
		imshow(windowName2, editedImage1);
		break;
	case 6: case 8: case 9:
		windowName1 = "Image"; windowName2 = "Histogram";
		namedWindow(windowName1, WINDOW_AUTOSIZE);
		namedWindow(windowName2, WINDOW_AUTOSIZE);
		imshow(windowName1, originImage1);
		imshow(windowName2, editedImage1);
		break;
	case 7:case 10: case 11:
		windowName1 = "Image1"; windowName2 = "Histogram Image1"; windowName3 = "Image2"; windowName4 = "Histogram Image2";
		namedWindow(windowName1, WINDOW_AUTOSIZE);
		namedWindow(windowName2, WINDOW_AUTOSIZE);
		namedWindow(windowName3, WINDOW_AUTOSIZE);
		namedWindow(windowName4, WINDOW_AUTOSIZE);
		imshow(windowName1, originImage1);
		imshow(windowName3, originImage2);
		imshow(windowName2, editedImage1);
		imshow(windowName4, editedImage2);
		break;
	}
	
	waitKey(0);
	return 0;
}
*/