#include "RGBHistogram.h"

using namespace std;
using namespace cv;

RGB_Histogram::RGB_Histogram() {
	numberBin = 0;
	r_mean = g_mean = b_mean = r_variant = g_variant = b_variant = 0;
}

RGB_Histogram::RGB_Histogram(const Mat image, int numberBins) {
	if (numberBins > 0) {
		Mat temp = image.clone();
		numberBin = numberBins;
		float bin_width = float(256) / numberBin;
		r_hist.resize(numberBin, 0);
		g_hist.resize(numberBin, 0);
		b_hist.resize(numberBin, 0);
		for (int y = 0; y < image.rows; y++)
			for (int x = 0; x < image.cols; x++) {				//tính toán số lượng pixel thuộc các bin màu cho từng kênh màu
				b_hist[int(temp.at<Vec3b>(y, x)[0] / bin_width)]++;
				g_hist[int(temp.at<Vec3b>(y, x)[1] / bin_width)]++;
				r_hist[int(temp.at<Vec3b>(y, x)[2] / bin_width)]++;
			}
	}
	r_mean = g_mean = b_mean = r_variant = g_variant = b_variant = 0;
	for (int i = 0; i < numberBin; i++) {						//tính toán trung binh và phươn sai của từng kênh màu
		r_mean += r_hist[i];	r_variant += r_hist[i] * r_hist[i];
		g_mean += g_hist[i];	g_variant += g_hist[i] * g_hist[i];
		b_mean += b_hist[i];	b_variant += b_hist[i] * b_hist[i];
	}
	r_mean /= numberBin;
	g_mean /= numberBin;
	b_mean /= numberBin;
	r_variant = r_variant / numberBin - r_mean * r_mean;		
	g_variant = g_variant / numberBin - g_mean * g_mean;
	b_variant = b_variant / numberBin - b_mean * b_mean;
}

Mat RGB_Histogram::drawHistogramToAnImage(int width, int height) {
	Mat ans(height, width, CV_8UC3, Scalar(255, 255, 255));
	int max = 0;
	for (int i = 0; i < numberBin; i++) {
		if (r_hist[i] > max)
			max = r_hist[i];
		if (g_hist[i] > max)
			max = g_hist[i];
		if (b_hist[i] > max)
			max = b_hist[i];
	}
	float heightUnit = float(height - 1) / max;			//tính độ, cao rộng từng bin màu dựa trên chiều cao, rộng của ma trận hình
	float widthUnit = float(width) / numberBin;
	//line(ans, Point(0, 0), Point(0, height - 1), Scalar(200, 200, 200), 1);
	for (int i = 1; i < numberBin; i++) {				//sử dụng line để nối từng điểm trên histogram
		//line(ans, Point(i*widthUnit, 0), Point(i*widthUnit, height - 1), Scalar(200, 200, 200), 1);
		line(ans, Point((i - 1)*widthUnit, height - 1 - int(r_hist[i - 1] * heightUnit)), Point(i*widthUnit, height - 1 - int(r_hist[i] * heightUnit)), Scalar(0, 0, 255), 1);
		line(ans, Point((i - 1)*widthUnit, height - 1 - int(g_hist[i - 1] * heightUnit)), Point(i*widthUnit, height - 1 - int(g_hist[i] * heightUnit)), Scalar(0, 255, 0), 1);
		line(ans, Point((i - 1)*widthUnit, height - 1 - int(b_hist[i - 1] * heightUnit)), Point(i*widthUnit, height - 1 - int(b_hist[i] * heightUnit)), Scalar(255, 0, 0), 1);
	}

	return ans;
}

float RGB_Histogram::compare(RGB_Histogram other) {
	float r_multiplicative_sum = 0, g_multiplicative_sum = 0, b_multiplicative_sum = 0;
	for (int i = 0; i < numberBin; i++) {
		r_multiplicative_sum += r_hist[i] * other.r_hist[i];
		g_multiplicative_sum += g_hist[i] * other.g_hist[i];
		b_multiplicative_sum += b_hist[i] * other.b_hist[i];
	}
	float temp;
	temp = sqrt(r_variant*other.r_variant);
	if (temp == 0)
		r_multiplicative_sum = 0;
	else
	r_multiplicative_sum = ((r_multiplicative_sum / numberBin) - r_mean * other.r_mean) / temp;
	temp = sqrt(g_variant*other.g_variant);
	if (temp == 0)
		g_multiplicative_sum = 0;
	else
		g_multiplicative_sum = ((g_multiplicative_sum / numberBin) - g_mean * other.g_mean) / temp;
	temp = sqrt(b_variant*other.b_variant);
	if (temp == 0)
		b_multiplicative_sum = 0;
	else
		b_multiplicative_sum = ((b_multiplicative_sum / numberBin) - b_mean * other.b_mean) / temp;
	return (r_multiplicative_sum + g_multiplicative_sum + b_multiplicative_sum) / 3;
}