#ifndef __OPENCV_HEADER_H__

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/opencv.hpp>

#include <iostream>

#include <math.h>
#include <vector>
#include <string>

#endif // !__OPENCV_HEADER_H__