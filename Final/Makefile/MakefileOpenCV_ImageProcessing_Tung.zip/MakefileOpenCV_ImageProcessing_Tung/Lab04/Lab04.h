#include "../Headers/OpencvHeaders.h"

#ifndef __LAB04_H__
#define __LAB04_H__

using namespace std;
using namespace cv;

long long combi(int n, int k);

/*Hàm lọc nhiễu trung bình cho ảnh truyền vào
  Tham số: Ma trận ảnh truyền vào, kích thước nhân bề ngang, kích thước nhân bề dọc
  Trả về: Ma trận ảnh sau biến đổi
*/
Mat meanFiltering(Mat origin, int xSize, int ySize, int numberChannels = 3);

/*Hàm lọc nhiễu dựa trên toán tử Gaussian cho ảnh truyền vào
  Tham số: Ma trận ảnh truyền vào, kích thước nhân bề ngang, kích thước nhân bề dọc, giá trị sigma theo bề ngang, giá trị sigma theo bề dọc
  Trả về: Ma trận ảnh sau biến đổi
*/
Mat GaussFiltering(Mat origin, int xSize, int ySize, float xSigma,float ySigma, int numberChannels = 3);

/*Hàm lọc nhiễu trung vị cho ảnh truyền vào
  Tham số: Ma trận ảnh truyền vào, kích thước nhân bề ngang, kích thước nhân bề dọc
  Trả về: Ma trận ảnh sau biến đổi
*/
Mat medianFiltering(Mat origin, int xSize, int ySize, int numberChannels = 3);

/*Hàm hiển thị ảnh ra màn hình
  Tham số: Ma trận điểm ảnh của ảnh cần hiển thị, chuỗi tên của cửa sổ
  Trả về: không có
*/
//void showImage(const Mat &image, string windowName);

#endif // !__LAB04_H__