﻿#include "Lab04.h"

using namespace std;
using namespace cv;

long long combi(int n, int k)
{
	long long ans = 1;
	k = k > n - k ? n - k : k;
	int j = 1;
	for (; j <= k; j++, n--)
	{
		if (n%j == 0)
		{
			ans *= n / j;
		}
		else
			if (ans%j == 0)
			{
				ans = ans / j * n;
			}
			else
			{
				ans = (ans*n) / j;
			}
	}
	return ans;
}

Mat meanFiltering(Mat origin, int xSize, int ySize, int numberChannels) {
	Mat answer = origin.clone();
	if (xSize <= 0||ySize<=0)
		return answer;
	
	Mat mask(ySize, xSize, CV_32F);
	int xStart = floor(-((float(xSize) - 1) / 2)), xEnd = floor((float(xSize) - 1) / 2), xCenter = floor(float(xSize) / 2);
	int yStart = floor(-((float(ySize) - 1) / 2)), yEnd = floor((float(ySize) - 1) / 2), yCenter = floor(float(ySize) / 2);
	for (int i = yStart; i <= yEnd; i++)
		for (int j = xStart; j <= xEnd; j++) {
			mask.at<float>(yCenter + i, xCenter + j) = float(1) / (xSize * ySize);
		}
	float result = 0;
	for (int y = 0; y < origin.rows; y++)
		for (int x = 0; x < origin.cols; x++) {
			for (int color = 0; color < numberChannels; color++) {
				result = 0;
				for (int i = yStart; i <= yEnd; i++)
					for (int j = xStart; j <= xEnd; j++) {
						if ((y + i >= 0 && y + i < origin.rows&&x + j >= 0 && x + j < origin.cols))
							result += mask.at<float>(yCenter + i, xCenter + j) * origin.at<Vec3b>(y + i, x + j)[color];
						else
							result += 0;
					}
				answer.at<Vec3b>(y, x)[color] = round(result);
			}
		}
	if (numberChannels == 1) {
		for (int y = 0; y < origin.rows; y++)
			for (int x = 0; x < origin.cols; x++) {
				answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
				answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];
			}
	}
	return answer;
}

Mat GaussFiltering(Mat origin, int xSize, int ySize, float xSigma,float ySigma, int numberChannels) {
	Mat answer = origin.clone();
	if (xSize <= 0||ySize<=0)
		return answer;
	Mat mask(ySize, xSize , CV_32F);
	int xStart = floor(-((float(xSize) - 1) / 2)), xEnd = floor((float(xSize) - 1) / 2), xCenter = floor(float(xSize) / 2);
	int yStart = floor(-((float(ySize) - 1) / 2)), yEnd = floor((float(ySize) - 1) / 2), yCenter = floor(float(ySize) / 2);
	float sum = 0;
	for (int i = yStart; i <= yEnd; i++) {
		for (int j = xStart; j <= xEnd; j++) {
			mask.at<float>(yCenter + i, xCenter + j) = float(1) / (2 * 3.14159265359*xSigma*ySigma)*exp(-float(i*i) / (2 * ySigma) - float(j * j) / (2 * xSigma));
			sum += mask.at<float>(yCenter + i, xCenter + j);
			//cout<< mask.at<float>(yCenter + i, xCenter + j)<<" ";
		}
		//cout << endl;
	}

	for (int i = yStart; i <= yEnd; i++) {
		for (int j = xStart; j <=xEnd; j++) {
			mask.at<float>(yCenter + i, xCenter + j) /= sum;
		}
	}

	float result = 0;
	for (int y = 0; y < origin.rows; y++)
		for (int x = 0; x < origin.cols; x++) {
			for (int color = 0; color < numberChannels; color++) {
				result = 0;
				for (int i = yStart; i <= yEnd; i++)
					for (int j = xStart; j <= xEnd; j++) {
						if ((y + i >= 0 && y + i < origin.rows&&x + j >= 0 && x + j < origin.cols))
							result += mask.at<float>(yCenter + i, xCenter + j) * origin.at<Vec3b>(y + i, x + j)[color];
						else
							result += 0;

					}
				answer.at<Vec3b>(y, x)[color] = round(result);
			}
		}
	if (numberChannels == 1) {
		for (int y = 0; y < origin.rows; y++)
			for (int x = 0; x < origin.cols; x++) {
				answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
				answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];
			}
	}

	return answer;
}

Mat medianFiltering(Mat origin, int xSize, int ySize, int numberChannels) {
	Mat answer = origin.clone();
	if (xSize <= 0 || ySize <= 0)
		return answer;
	
	Mat mask(ySize, xSize, CV_32F);
	int xStart = floor(-((float(xSize) - 1) / 2)), xEnd = floor((float(xSize) - 1) / 2), xCenter = floor(float(xSize) / 2);
	int yStart = floor(-((float(ySize) - 1) / 2)), yEnd = floor((float(ySize) - 1) / 2), yCenter = floor(float(ySize) / 2);
	vector<uchar> temp;
	float result = 0;
	for (int y = 0; y < origin.rows; y++)
		for (int x = 0; x < origin.cols; x++) {
			for (int color = 0; color < numberChannels; color++) {
				temp.clear();
				for (int i = yStart; i <= yEnd; i++)
					for (int j = xStart; j <= xEnd; j++) {
						if ((y + i >= 0 && y + i < origin.rows&&x + j >= 0 && x + j < origin.cols))
							temp.push_back(origin.at<Vec3b>(y + i, x + j)[color]);

					}
				sort(temp.begin(), temp.end());
				result = temp[floor(float(temp.size()) / 2)];
				answer.at<Vec3b>(y, x)[color] = round(result);
			}
		}
	if (numberChannels == 1) {
		for (int y = 0; y < origin.rows; y++)
			for (int x = 0; x < origin.cols; x++) {
				answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
				answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];
			}
	}
	return answer;
}

/*
void showImage(const Mat &image, string windowName) {
	namedWindow(windowName, WINDOW_AUTOSIZE);
	imshow(windowName, image);
}
*/

/*
#define NUMBER_COMMAND 6
int main(int argc, char** argv) {
	string commandList[NUMBER_COMMAND] = { "--mg","--mc","--meg","--mec","--gg","--gc" };			//những lệnh hỗ trợ
	Mat originImage1, originImage2, editedImage1, editedImage2;			//(1) khởi tạo đối tượng Matrix để xử lý dữ liệu ảnh dưới dạng các ma trận điểm ảnh
	int command;

	if (argc < 3) {
		cout << "Wrong argument number input!" << endl;
		return -1;
	}


	originImage1 = imread(argv[2], IMREAD_COLOR);		//(2) hàm imread tiến hành đọc một file ảnh với đường dẫn được nhập vào từ command line và trả về ảnh đó dưới dạng ma trận điểm ảnh Mat

	if (!originImage1.data)
	{
		cout << "Can't open image" << std::endl;
		return -1;
	}

	for (command = 0; command < NUMBER_COMMAND; command++) {								//tiến hành việc kiểm tra lệnh người dùng nhập vào
		if (strcmp(commandList[command].c_str(), strlwr(argv[1])) == 0)
			break;
	}

	switch (command) {
	case 0:
		if (argc < 5) {
			cout << "Wrong argument number input!" << endl;
			return -1;
		}
		editedImage1 = meanFiltering(originImage1, atoi(argv[3]),atoi(argv[4]),1);
		showImage(originImage1, "Original Image");
		showImage(editedImage1, "Edited Image");
		break;
	case 1:
		if (argc < 5) {
			cout << "Wrong argument number input!" << endl;
			return -1;
		}
		editedImage1 = meanFiltering(originImage1, atoi(argv[3]), atoi(argv[4]), 3);
		showImage(originImage1, "Original Image");
		showImage(editedImage1, "Edited Image");
		break;
	case 2:
		if (argc < 5) {
			cout << "Wrong argument number input!" << endl;
			return -1;
		}
		editedImage1 = medianFiltering(originImage1, atoi(argv[3]),atoi(argv[4]),1);
		showImage(originImage1, "Original Image");
		showImage(editedImage1, "Edited Image");
		break;
	case 3:
		if (argc < 5) {
			cout << "Wrong argument number input!" << endl;
			return -1;
		}
		editedImage1 = medianFiltering(originImage1, atoi(argv[3]), atoi(argv[4]), 3);
		showImage(originImage1, "Original Image");
		showImage(editedImage1, "Edited Image");
		break;
	case 4:
		if (argc < 7) {
			cout << "Wrong argument number input!" << endl;
			return -1;
		}
		editedImage1 = GaussFiltering(originImage1, atoi(argv[3]), atoi(argv[4]),atof(argv[5]),atof(argv[6]),1);
		showImage(originImage1, "Original Image");
		showImage(editedImage1, "Edited Image");
		break;
	case 5:
		if (argc < 7) {
			cout << "Wrong argument number input!" << endl;
			return -1;
		}
		editedImage1 = GaussFiltering(originImage1, atoi(argv[3]), atoi(argv[4]), atof(argv[5]), atof(argv[6]), 3);
		showImage(originImage1, "Original Image");
		showImage(editedImage1, "Edited Image");
		break;
	default:
		cout << "Please input right command!" << endl;
		return -1;
	}

	waitKey(0);
	return 0;
}

//int main(int argc, char** argv) {
//	Mat originImage1, originImage2, editedImage1, editedImage2;
//
//
//	originImage1 = imread("test6.png", IMREAD_COLOR);
//	if (!originImage1.data)
//	{
//		cout << "Can't open image" << std::endl;
//		return -1;
//	}
//
//	editedImage1 = GaussFiltering(originImage1,3,5,1,1);
//	GaussianBlur(originImage1, editedImage2, Size(3, 5), 1, 1);
//	cout << "why?";
//	showImage(originImage1, "Original Image");
//	showImage(editedImage1, "Edited Image");
//	showImage(editedImage2, "OpenCV");
//
//
//	waitKey(0);
//	return 0;
//}
*/