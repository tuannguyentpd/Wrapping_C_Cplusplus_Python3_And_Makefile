#include "../Headers/OpencvHeaders.h"

#ifndef __LAB02_H__
#define __LAB02_H__

using namespace std;
using namespace cv;

/*Hàm kiểm tra ma trận ảnh có phải là ảnh trắng đen hay không
  Tham số: Ma trận điểm ảnh cần kiểm tra
  Trả về: false nếu là ảnh màu, true nếu là ảnh trắng đen
*/
//bool isGrayscaleImage(Mat image);

/*Hàm chuyển đổi ảnh màu sang trắng đen
  Tham số: Ma trận điểm ảnh cần chuyển đổi, tỷ lệ màu R,G,B khi tiến hành chuyển (ở đây mặc định các tham số này dựa trên luminosity method)
  Trả về: Ma trận ảnh đã chuyển đổi
*/
//Mat convertToGrayScaleImage(const Mat origin, float redScale, float greenScale, float blueScale);

/*Hàm tìm max của 3 giá trị
  Tham số : 3 số thực
  Trả về : giá trị lớn nhất
*/
inline float myMax(float a, float b, float c);

/*Hàm tìm min của 3 giá trị
  Tham số : 3 số thực
  Trả về : giá trị nhỏ nhất
*/
inline float myMin(float a, float b, float c);

/*Hàm chuyển hình từ định dạng màu RGB sang HSV
  Tham số: ma trận điểm ảnh cần chuyển đổi
  Trả về: ma trận ảnh đã chuyển đổi
*/
Mat convertToRGBImage(const Mat origin);

/*Hàm chuyển hình từ định dạng màu HSV sang RGB
  Tham số: ma trận điểm ảnh cần chuyển đổi
  Trả về: ma trận ảnh đã chuyển đổi
*/
Mat convertToHSVImage(const Mat origin);


enum Color_Space { HSV_COLOR, RGB_COLOR };


/*Hàm cân bằng ảnh trên kênh H của ảnh HSV và chuyển về ảnh RGB sử dụng hàm thư viện OpenCV
  Tham số: ma trận ảnh
  Trả về: ma trận ảnh đã chuyển đổi
*/
Mat equalizeHChannelInHSVImageOpenCV(const Mat& inputImage);

/*Hàm cân bằng ảnh trên cả 3 kênh R,G,B của ảnh RGB sử dụng hàm thư viện OpenCV
  Tham số: ma trận ảnh
  Trả về: ma trận ảnh đã chuyển đổi
*/
Mat equalize3ChannelsRGBImageOpenCV(const Mat& inputImage);

/*Hàm cân bằng ảnh trên ảnh GrayScale sử dụng hàm thư viện OpenCV
  Tham số: ma trận ảnh
                      ^~~
/home/tuan/Desktop/WrappingC_C++_Python/CMakeOpenCV_ImageProcessing_Tung/Lab02/Lab02.h:71:34: error: ‘string’ has not been declared
 void showImage(const Mat &image, string windowName);
                                  ^~~~~~
  Trả về: ma trận ảnh đã chuyển đổi
*/
Mat equalizeGrayScaleImageOpenCV(const Mat& inputImage);

/*Hàm hiển thị ảnh ra màn hình
  Tham số: Ma trận điểm ảnh của ảnh cần hiển thị, chuỗi tên của cửa sổ
  Trả về: không có
*/
//void showImage(const Mat &image, string windowName);

#endif // !__LAB02_H__