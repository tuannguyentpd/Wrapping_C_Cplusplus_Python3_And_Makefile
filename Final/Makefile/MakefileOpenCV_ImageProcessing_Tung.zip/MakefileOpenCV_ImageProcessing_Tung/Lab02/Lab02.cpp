﻿#include "../Headers/OpencvHeaders.h"
#include "Lab02.h"

using namespace std;
using namespace cv;


/*
bool isGrayscaleImage(Mat image) {
	bool ans = true;
	for (int y = 0; y < image.rows; y++) {
		for (int x = 0; x < image.cols; x++) {						//truy cập từng điểm ảnh trong ma trận
			if (image.at<Vec3b>(y, x)[0] != image.at<Vec3b>(y, x)[1] || image.at<Vec3b>(y, x)[0] != image.at<Vec3b>(y, x)[2]) { //kiểm tra xem các điểm màu có bằng nhau không nếu khác thì cho biến kết quả là false và trả về
				ans = false;
				break;
			}
		}
		if (!ans)
			break;
	}
	return ans;
}
*/

/*
Mat convertToGrayScaleImage(const Mat origin, float redScale, float greenScale, float blueScale) {
	float gray;
	Mat answer;
	answer = origin.clone();
	for (int y = 0; y < origin.rows; y++)
		for (int x = 0; x < origin.cols; x++) {						//truy cập từng điểm ảnh trong ma trận
			gray = origin.at<Vec3b>(y, x)[0] * redScale + origin.at<Vec3b>(y, x)[1] * greenScale + origin.at<Vec3b>(y, x)[2] * blueScale;		//tính mức xám cho từng bộ điểm màu trong điểm ảnh đó
			for (int color = 0; color < 3; color++)
				answer.at<Vec3b>(y, x)[color] = (uchar)gray;		//áp mức xám vừa tính cho cả ba điểm màu R,G,B
		}
	return answer;
}
*/

inline float myMax(float a, float b, float c) {
	if (a > b&&a > c)
		return a;
	else if (b > c&&b > a)
		return b;
	else
		return c;
}

inline float myMin(float a, float b, float c) {
	if (a < b&&a < c)
		return a;
	else if (b < c&&b < a)
		return b;
	else
		return c;
}

Mat convertToRGBImage(const Mat origin) {
	Mat ans;
	ans = origin.clone();

	float h = 0, s = 0, v = 0, c = 0, m = 0, x_ = 0, r = 0, g = 0, b = 0;
	for (int y = 0; y < origin.rows; y++) {
		for (int x = 0; x < origin.cols; x++) {						//truy cập từng điểm ảnh trong ma trận và thực hiện tính toán việc chuyển đổi từng bộ giá trị R,G,B sang H,S,V
			h = origin.at<Vec3b>(y, x)[0] / float(255) * 359;
			s = origin.at<Vec3b>(y, x)[1] / float(255);
			v = origin.at<Vec3b>(y, x)[2] / float(255);
			c = v * s;
			m = v - c;
			x_ = c * (1 - abs(fmod(h / 60, 2) - 1));
			if (h >= 0 && h < 60) {
				r = c + m; g = x_ + m; b = m;
			}
			else if (h >= 60 && h < 120) {
				r = x_ + m; g = c + m; b = m;
			}
			else if (h >= 120 && h < 180) {
				r = m; g = c + m; b = x_ + m;
			}
			else if (h >= 180 && h < 240) {
				r = m; g = x_ + m; b = c + m;
			}
			else if (h >= 240 && h < 300) {
				r = x_ + m; g = m; b = c + m;
			}
			else {
				r = c + m; g = m; b = x_ + m;
			}
			ans.at<Vec3b>(y, x)[0] = uchar(round(b * 255));
			ans.at<Vec3b>(y, x)[1] = uchar(round(g * 255));
			ans.at<Vec3b>(y, x)[2] = uchar(round(r * 255));
		}
	}
	return ans;
}

Mat convertToHSVImage(const Mat origin) {
	Mat ans;
	ans = origin.clone();
	float r = 0, g = 0, b = 0, min = 0, max = 0, delta = 0, hTemp = 0, sTemp = 0, vTemp = 0;
	for (int y = 0; y < origin.rows; y++) {
		for (int x = 0; x < origin.cols; x++) {						//truy cập từng điểm ảnh trong ma trận và thực hiện tính toán việc chuyển đổi từng bộ giá trị H,S,V sang R,G,B
			b = origin.at<Vec3b>(y, x)[0];
			b /= float(255);
			g = origin.at<Vec3b>(y, x)[1];
			g /= float(255);
			r = origin.at<Vec3b>(y, x)[2];
			r /= float(255);
			min = myMin(r, g, b);
			max = myMax(r, g, b);
			vTemp = max;
			delta = max - min;
			if (delta == 0)
				hTemp = 0;
			else if (r == max)
				hTemp = 60 * fmod((g - b) / delta, 6);
			else if (g == max)
				hTemp = 120 + 60 * (b - r) / (delta);
			else if (b == max)
				hTemp = 240 + 60 * (r - g) / (delta);
			if (hTemp < 0)
				hTemp += 360;
			if (max > 0)
				sTemp = (delta) / max;
			else
				sTemp = 0;
			ans.at<Vec3b>(y, x)[0] = uchar(round(hTemp / 359 * 255));
			ans.at<Vec3b>(y, x)[1] = uchar(round(sTemp * 255));
			ans.at<Vec3b>(y, x)[2] = uchar(round(vTemp * 255));

		}

	}

	return ans;
}

Mat equalizeHChannelInHSVImageOpenCV(const Mat& inputImage)
{
	if (inputImage.channels() >= 3)
	{
		Mat temp = inputImage.clone();

		cvtColor(inputImage, temp, COLOR_BGR2HSV);

		vector<Mat> channels;
		split(temp, channels);

		equalizeHist(channels[0], channels[0]);
		//equalizeHist(channels[1], channels[1]);
		//equalizeHist(channels[2], channels[2]);

		merge(channels, temp);

		cvtColor(temp, temp, COLOR_HSV2BGR);

		return temp;
	}
	return Mat();
}

Mat equalize3ChannelsRGBImageOpenCV(const Mat& inputImage)
{
	if (inputImage.channels() >= 3)
	{
		Mat temp = inputImage.clone();

		cvtColor(inputImage, temp, COLOR_BGR2HSV);

		vector<Mat> channels;
		split(temp, channels);

		equalizeHist(channels[0], channels[0]);
		equalizeHist(channels[1], channels[1]);
		equalizeHist(channels[2], channels[2]);

		merge(channels, temp);

		cvtColor(temp, temp, COLOR_HSV2BGR);

		return temp;
	}
	return Mat();
}

Mat equalizeGrayScaleImageOpenCV(const Mat& inputImage) {
	Mat temp = inputImage.clone();

	cvtColor(inputImage, temp, COLOR_BGR2GRAY);

	equalizeHist(temp,temp);

	cvtColor(temp, temp, COLOR_GRAY2BGR);

	return temp;
}

/*
void showImage(const Mat &image, string windowName) {
	namedWindow(windowName, WINDOW_AUTOSIZE);
	imshow(windowName, image);
}
*/

/*
#define NUMBER_COMMAND 3

int main(int agrc, char** argv) {
	string commandList[NUMBER_COMMAND] = { "--hqgray","--hqrgb","--hqhsv" };			//những lệnh hỗ trợ
	Mat originImage1, originImage2, editedImage1, editedImage2;			//(1) khởi tạo đối tượng Matrix để xử lý dữ liệu ảnh dưới dạng các ma trận điểm ảnh
	int command;

	originImage1 = imread(argv[2], IMREAD_COLOR);		//(2) hàm imread tiến hành đọc một file ảnh với đường dẫn được nhập vào từ command line và trả về ảnh đó dưới dạng ma trận điểm ảnh Mat

	for (command = 0; command < NUMBER_COMMAND; command++) {								//tiến hành việc kiểm tra lệnh người dùng nhập vào
		if (strcmp(commandList[command].c_str(), strlwr(argv[1])) == 0)
			break;
	}

	Histogram hist1, hist2;

	

	switch (command) {
	case 0:
		if (!isGrayscaleImage(originImage1)) {
			cout << "Please input grayscale image!" << endl;
			//originImage1=convertToGrayScaleImage(originImage1);
			return -1;
		}
		hist1 = Histogram(originImage1,RGB_COLOR);
		hist2 = hist1.equalization();
		showImage(hist1.getImage(), "Original Image");
		showImage(hist2.getImage(), "Equalized Histgogram Image");
		showImage(hist1.drawHistogramToAnImage(), "Original Image Histogram");
		showImage(hist2.drawHistogramToAnImage(), "Equalized Imaged Histogram");
		break;
	case 1:
		if (isGrayscaleImage(originImage1)) {
			cout << "Please input color image!" << endl;
			return -1;
		}
		hist1 = Histogram(originImage1,RGB_COLOR);
		hist2 = hist1.equalization();
		showImage(hist1.getImage(), "Original Image");
		showImage(hist2.getImage(), "Equalized Histgogram Image");
		showImage(hist1.drawHistogramToAnImage(), "Original Image Histogram");
		showImage(hist2.drawHistogramToAnImage(), "Equalized Imaged Histogram");
		break;
	case 2:
		hist1 = Histogram(convertToHSVImage(originImage1),HSV_COLOR);
		hist2 = hist1.equalization(0);
		showImage(originImage1, "Original RGB Image");
		showImage(convertToRGBImage(hist2.getImage()), "Equalized Histgogram On Hue Channel And Convert To RGB Image");
		showImage(hist1.drawHistogramToAnImage(), "Original Image Histogram");
		showImage(hist2.drawHistogramToAnImage(), "Equalized Imaged Histogram");
		break;
	default: 
		cout << "Please input right command!" << endl; 
		return -1;

	}

	//Mat test;
	//test = equalizeHChannelInHSVImageOpenCV(originImage1);
	//showImage(test, "OpenCV");

	waitKey(0);
	return 0;
}
*/