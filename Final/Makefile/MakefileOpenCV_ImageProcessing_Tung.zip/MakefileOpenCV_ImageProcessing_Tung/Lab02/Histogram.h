#include "Lab02.h"
#include "../Headers/OpencvHeaders.h"

#ifndef __HISTOGRAM_H__
#define __HISTOGRAM_H__

using namespace std;
using namespace cv;

class Histogram {
private:
	Mat im;
	int numberBin;
	int numberChannel;
	vector<vector<int>> hist;
	vector<float> mean;
	vector<float> var;
	bool isGrayScale;
	Color_Space type;

	bool isGrayscaleImage(Mat image);
	//Mat temp;
public:
	Histogram();

	/*Hàm khởi tạo sao chép cho class Histogram
	  Tham số: đổi tượng Histogram cần chuyển đổi
	*/
	Histogram(const Histogram &other);

	/*Hàm khởi tạo cho class Histogram
	  Tham số: Ma trận điểm ảnh cần tính,không gian màu của ảnh (kiểu màu), số bin màu cần tạo ra cho mỗi kênh màu
	*/
	Histogram(const Mat image, Color_Space colorType, int numberBins = 256);

	/*Hàm chuyển đổi histogram sang ma trận hình ảnh biểu diễn histogram
	Tham số: chiều rộng của ảnh, chiều cao của ảnh
	Trả về: Ma trận ảnh
	*/
	Mat drawHistogramToAnImage(int width = 550, int height = 400);

	/*Hàm so sánh 2 histogram dựa trên độ đo Pearson correlation coefficient
	Tham số: Histogram cần được so sánh với histogram này
	Trả về: giá trị độ tương đồng -1 đến 1 (1: giống nhau hoàn toàn, 0: không giống, -1: trái ngược nhau)
	*/
	float compare(Histogram other);

	/*Hàm cân bằng lược đồ của ảnh
	Tham số: không có
	Trả về: một đối tượng histogram với ảnh và histogram sau khi cân bằng
	*/
	Histogram equalization(int channel=-1);

	Mat getImage();
};

#endif // !__HISTOGRAM_H__