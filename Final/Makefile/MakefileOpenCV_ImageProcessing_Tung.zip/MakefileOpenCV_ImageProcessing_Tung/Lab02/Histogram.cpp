
#include "Histogram.h"

using namespace std;
using namespace cv;

bool Histogram::isGrayscaleImage(Mat image) {
	bool ans = true;
	if (type == RGB_COLOR) {
		for (int y = 0; y < image.rows; y++) {
			for (int x = 0; x < image.cols; x++) {						//truy cập từng điểm ảnh trong ma trận
				if (image.at<Vec3b>(y, x)[0] != image.at<Vec3b>(y, x)[1] || image.at<Vec3b>(y, x)[0] != image.at<Vec3b>(y, x)[2]) { //kiểm tra xem các điểm màu có bằng nhau không nếu khác thì cho biến kết quả là false và trả về
					ans = false;
					break;
				}
			}
			if (!ans)
				break;
		}
	}
	else {
		for (int y = 0; y < image.rows; y++) {
			for (int x = 0; x < image.cols; x++) {						//truy cập từng điểm ảnh trong ma trận
				if (image.at<Vec3b>(y, x)[0] != 0) { //kiểm tra xem các điểm màu có bằng nhau không nếu khác thì cho biến kết quả là false và trả về
					ans = false;
					break;
				}
			}
			if (!ans)
				break;
		}
	}
	return ans;
}

Histogram::Histogram() {
	numberBin = 0;
	numberChannel = 0;
}

Histogram::Histogram(const Histogram &other) {
	im = other.im.clone();
	numberBin = other.numberBin;
	numberChannel = other.numberChannel;
	hist = other.hist;
	mean = other.mean;
	var = other.var;
	isGrayScale = false;
	type = RGB_COLOR;
}

Histogram::Histogram(const Mat image, Color_Space colorType, int numberBins) {
	if (numberBins > 0) {
		type = colorType;
		isGrayScale = isGrayscaleImage(image);
		if (isGrayScale)
			numberChannel = 1;
		else
			numberChannel = 3;
		im = image.clone();
		numberBin = numberBins;
		hist.resize(numberChannel);
		mean.resize(numberChannel, 0);
		var.resize(numberChannel, 0);
		for (int i = 0; i < numberChannel; i++) {
			hist[i].resize(numberBin, 0);
		}
		float bin_width = float(256) / numberBin;
		if (type == HSV_COLOR && isGrayScale)						// xét đối với trường hợp là màu hsv và là ảnh grayscale thì chỉ tính histogram cho kênh v
			for (int y = 0; y < image.rows; y++)
				for (int x = 0; x < image.cols; x++) {				//tính toán số lượng pixel thuộc các bin màu cho từng kênh màu
					for (int i = 0; i < numberChannel; i++) {
						hist[i][floor(image.at<Vec3b>(y, x)[2] / bin_width)]++;
					}
				}
		else
			for (int y = 0; y < image.rows; y++)
				for (int x = 0; x < image.cols; x++) {				//tính toán số lượng pixel thuộc các bin màu cho từng kênh màu
					for (int i = 0; i < numberChannel; i++) {
						hist[i][floor(image.at<Vec3b>(y, x)[i] / bin_width)]++;
					}
				}
		for (int i = 0; i < numberBin; i++) {						//tính toán trung binh và phươn sai của từng kênh màu
			for (int j = 0; j < numberChannel; j++) {
				mean[j] += hist[j][i];
				var[j] += hist[j][i] * hist[j][i];
			}
		}
		for (int i = 0; i < numberChannel; i++)
			mean[i] /= numberBin;
		for (int i = 0; i < numberChannel; i++)
			var[i] = var[i] / numberBin - mean[i] * mean[i];
	}
}

Mat Histogram::drawHistogramToAnImage(int width, int height) {
	Mat ans(height, width, CV_8UC3, Scalar(255, 255, 255));
	int max = 0;
	for (int i = 0; i < numberBin; i++)
		for (int j = 0; j < numberChannel; j++)
			if (hist[j][i] > max)
				max = hist[j][i];
	float heightUnit = float(height - 1) / max;			//tính độ, cao rộng từng bin màu dựa trên chiều cao, rộng của ma trận hình
	float widthUnit = float(width) / numberBin;
	//line(ans, Point(0, 0), Point(0, height - 1), Scalar(200, 200, 200), 1);
	vector<Scalar> color;
	color.resize(numberChannel);
	if (numberChannel == 1)
		color[0] = Scalar(0, 0, 0);
	if (numberChannel == 3) {
		color[0] = Scalar(255, 0, 0);
		color[1] = Scalar(0, 255, 0);
		color[2] = Scalar(0, 0, 255);
	}
	for (int i = 1; i < numberBin; i++) {				//sử dụng line để nối từng điểm trên histogram
		for (int j = 0; j < numberChannel; j++)
			line(ans, Point((i - 1)*widthUnit, height - 1 - int(hist[j][i - 1] * heightUnit)), Point(i*widthUnit, height - 1 - int(hist[j][i] * heightUnit)), color[j], 1);
	}
	return ans;
}

float Histogram::compare(Histogram other) {
	vector<float> coeff;
	coeff.resize(numberChannel, 0);
	for (int i = 0; i < numberBin; i++)
		for (int j = 0; j < numberChannel; j++)
			coeff[j] += hist[j][i] * other.hist[j][i];

	float temp;
	for (int i = 0; i < numberChannel; i++) {
		temp = sqrt(var[i] * other.var[i]);
		if (temp == 0)
			coeff[i] = 0;
		else
			coeff[i] = ((coeff[i] / numberBin) - mean[i] * other.mean[i]) / temp;
	}
	temp = 0;
	for (int i = 0; i < numberChannel; i++)
		temp += coeff[i];
	return temp / numberChannel;
}

Histogram Histogram::equalization(int channel) {
	Histogram ans = *this;

	if (isGrayScale&&type == HSV_COLOR) {
		ans.hist[0][0] = hist[0][0];
		for (int i = 1; i < numberBin; i++)
			ans.hist[2][i] = ans.hist[2][i - 1] + hist[2][i];
		for (int i = 0; i < numberBin; i++)
			ans.hist[2][i] = round((ans.hist[2][i] / float(ans.hist[2][ans.numberBin - 1]))*(ans.numberBin - 1));
		for (int y = 0; y < ans.im.rows; y++)
			for (int x = 0; x < ans.im.cols; x++)
				ans.im.at<Vec3b>(y, x)[2] = ans.hist[2][ans.im.at<Vec3b>(y, x)[2]];
	}
	else {
		if (channel == -1){
			ans.hist[0][0] = hist[0][0];
				for (int i = 1; i < numberBin; i++)
					for (int j = 0; j < numberChannel; j++) {
						ans.hist[j][i] = ans.hist[j][i - 1] + hist[j][i];
					}
			for (int i = 0; i < numberBin; i++)
				for (int j = 0; j < numberChannel; j++) {
					ans.hist[j][i] = round((ans.hist[j][i] / float(ans.hist[j][ans.numberBin - 1]))*(ans.numberBin - 1));
				}
			for (int y = 0; y < ans.im.rows; y++)
				for (int x = 0; x < ans.im.cols; x++)
					for (int i = 0; i < numberChannel; i++)
						ans.im.at<Vec3b>(y, x)[i] = ans.hist[i][ans.im.at<Vec3b>(y, x)[i]];
		}
		else {
			ans.hist[0][0] = hist[0][0];
			for (int i = 1; i < numberBin; i++)
					ans.hist[channel][i] = ans.hist[channel][i - 1] + hist[channel][i];
			for (int i = 0; i < numberBin; i++)
					ans.hist[channel][i] = round((ans.hist[channel][i] / float(ans.hist[channel][ans.numberBin - 1]))*(ans.numberBin - 1));
			for (int y = 0; y < ans.im.rows; y++)
				for (int x = 0; x < ans.im.cols; x++)
						ans.im.at<Vec3b>(y, x)[channel] = ans.hist[channel][ans.im.at<Vec3b>(y, x)[channel]];
		}
	}
	if (isGrayScale == true && type == RGB_COLOR) {
		for (int y = 0; y < ans.im.rows; y++)
			for (int x = 0; x < ans.im.cols; x++)
				for (int i = 1; i < 3; i++)
					ans.im.at<Vec3b>(y, x)[i] = (uchar)ans.im.at<Vec3b>(y, x)[0];
	}
	return Histogram(ans.im, ans.type, ans.numberBin);
}

Mat Histogram::getImage() {
	return im;
}