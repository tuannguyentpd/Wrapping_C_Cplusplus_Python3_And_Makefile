﻿#include "Lab03.h"

using namespace std;
using namespace cv;

Mat preservedRotateImage(Mat origin, int angle) {
	double diagonalLine = sqrt(origin.rows*origin.rows + origin.cols*origin.cols), radianAngle = angle * (3.14159265 / 180);
	Mat answer(abs(ceil(diagonalLine*sin(-acos(origin.cols / diagonalLine) + -radianAngle))), abs(ceil(diagonalLine*cos(acos(origin.cols / diagonalLine) + -radianAngle))), CV_8UC3, Scalar(0,0,0));
	int xCenter = origin.cols / 2, yCenter = origin.rows / 2, xCenterImage = answer.cols / 2, yCenterImage = answer.rows / 2;
	double x_, y_;
	int x_floor, y_floor, x_remain,y_remain;

	for (int y = 0; y < answer.rows; y++)
		for (int x = 0; x < answer.cols; x++) {
			x_ = xCenter+cos(-radianAngle)*(x-xCenterImage)+sin(-radianAngle)*(y-yCenterImage);
			y_ = yCenter+cos(-radianAngle)*(y - yCenterImage) - sin(-radianAngle)*(x - xCenterImage);
			x_floor = floor(x_);
			y_floor = floor(y_);
			x_remain = x_ - x_floor;
			y_remain = y_ - y_floor;
			if (x_floor < 0 || y_floor < 0 || ceil(x_) >= origin.cols || ceil(y_) >= origin.rows)
				continue;
			if (x_ == x_floor && y_ == y_floor)
				answer.at<Vec3b>(y, x) = origin.at<Vec3b>(y_, x_);
			else
				for (int i = 0; i < 3; i++)
					answer.at<Vec3b>(y, x)[i] = (uchar)((1 - y_remain)*((1 - x_remain)*origin.at<Vec3b>(y_floor, x_floor)[i] + (x_remain)*origin.at<Vec3b>(y_floor, ceil(x_))[i]) + (y_remain)*((1 - x_remain)*origin.at<Vec3b>(ceil(y_), x_floor)[i] + (x_remain)*origin.at<Vec3b>(ceil(y_), ceil(x_))[i]));
		}
	return answer;
}

Mat notPreservedRotateImage(Mat origin, int angle) {
	double radianAngle = angle * (3.14159265 / 180);
	Mat answer(origin.rows, origin.cols, CV_8UC3, Scalar(0, 0, 0));
	int xCenter = origin.cols / 2, yCenter = origin.rows / 2, xCenterImage = answer.cols / 2, yCenterImage = answer.rows / 2;
	double x_, y_;
	int x_floor, y_floor, x_remain, y_remain;

	for (int y = 0; y < answer.rows; y++)
		for (int x = 0; x < answer.cols; x++) {
			x_ = xCenter + cos(-radianAngle)*(x - xCenterImage) + sin(-radianAngle)*(y - yCenterImage);
			y_ = yCenter + cos(-radianAngle)*(y - yCenterImage) - sin(-radianAngle)*(x - xCenterImage);
			x_floor = floor(x_);
			y_floor = floor(y_);
			x_remain = x_ - x_floor;
			y_remain = y_ - y_floor;
			if (x_floor < 0 || y_floor < 0 || ceil(x_) >= origin.cols || ceil(y_) >= origin.rows)
				continue;
			if (x_ == x_floor && y_ == y_floor)
				answer.at<Vec3b>(y, x) = origin.at<Vec3b>(y_, x_);
			else
				for (int i = 0; i < 3; i++)
					answer.at<Vec3b>(y, x)[i] = (uchar)((1 - y_remain)*((1 - x_remain)*origin.at<Vec3b>(y_floor, x_floor)[i] + (x_remain)*origin.at<Vec3b>(y_floor, ceil(x_))[i]) + (y_remain)*((1 - x_remain)*origin.at<Vec3b>(ceil(y_), x_floor)[i] + (x_remain)*origin.at<Vec3b>(ceil(y_), ceil(x_))[i]));
		}
	return answer;
}


/*Hàm phóng to thu nhỏ ảnh trên hai trục x, y
  Tham số: Ma trận điểm ảnh cần thực hiện, hệ số trên trục x, hệ số trên trục y
  Trả về: Ma trận điểm ảnh sau thực hiện
*/
Mat scaleImage(Mat origin, float xScale, float yScale) {
	Mat answer(origin.rows*yScale, origin.cols*xScale, CV_8UC3, Scalar(0,0,0));
	int xCenter = origin.cols / 2, yCenter = origin.rows / 2, xCenterImage = answer.cols / 2, yCenterImage = answer.rows / 2;
	double x_, y_;
	double x_floor, y_floor,x_remain, y_remain;
	for (int y = 0; y < answer.rows; y++)
		for (int x = 0; x < answer.cols; x++) {
			x_ = (double(x)) / xScale;
			y_ = (double(y)) / yScale;
			x_floor = floor(x_);
			y_floor = floor(y_);
			x_remain = x_ - x_floor;
			y_remain = y_ - y_floor;
			if (x_floor < 0 || y_floor < 0 || ceil(x_) >= origin.cols || ceil(y_) >= origin.rows)
				continue;
			if (x_ == x_floor && y_ == y_floor)
				answer.at<Vec3b>(y, x) = origin.at<Vec3b>(y_, x_);
			else
				for (int i = 0; i < 3; i++)
					answer.at<Vec3b>(y, x)[i] = (uchar)((1 - y_remain)*((1 - x_remain)*origin.at<Vec3b>(y_floor, x_floor)[i] + (x_remain)*origin.at<Vec3b>(y_floor, ceil(x_))[i]) + (y_remain)*((1 - x_remain)*origin.at<Vec3b>(ceil(y_), x_floor)[i] + (x_remain)*origin.at<Vec3b>(ceil(y_), ceil(x_))[i]));
		}
	return answer;
}

/*
void showImage(const Mat &image, string windowName) {
	namedWindow(windowName, WINDOW_AUTOSIZE);
	imshow(windowName, image);
}
*/

/*
#define NUMBER_COMMAND 3
int main(int argc, char** argv) {
	string commandList[NUMBER_COMMAND] = { "-rotate","-rotaten","-scale" };			//những lệnh hỗ trợ
	Mat originImage1, originImage2, editedImage1, editedImage2;			//(1) khởi tạo đối tượng Matrix để xử lý dữ liệu ảnh dưới dạng các ma trận điểm ảnh
	int command;

	if (argc < 3) {
		cout << "Wrong argument number input!" << endl;
		return -1;
	}


	originImage1 = imread(argv[1], IMREAD_COLOR);		//(2) hàm imread tiến hành đọc một file ảnh với đường dẫn được nhập vào từ command line và trả về ảnh đó dưới dạng ma trận điểm ảnh Mat

	if (!originImage1.data)
	{
		cout << "Can't open image" << std::endl;
		return -1;
	}

	for (command = 0; command < NUMBER_COMMAND; command++) {								//tiến hành việc kiểm tra lệnh người dùng nhập vào
		if (strcmp(commandList[command].c_str(), strlwr(argv[2])) == 0)
			break;
	}

	switch (command) {
	case 0:
		if (argc < 4) {
			cout << "Wrong argument number input!" << endl;
			return -1;
		}
		editedImage1 = preservedRotateImage(originImage1,atoi(argv[3]));
		showImage(originImage1, "Original Image");
		showImage(editedImage1, "Edited Image");
		break;
	case 1:
		if (argc < 4) {
			cout << "Wrong argument number input!" << endl;
			return -1;
		}
		editedImage1 = notPreservedRotateImage(originImage1, atoi(argv[3]));
		showImage(originImage1, "Original Image");
		showImage(editedImage1, "Edited Image");
		break;
	case 2:
		if (argc < 5) {
			cout << "Wrong argument number input!" << endl;
			return -1;
		}
		editedImage1 = scaleImage(originImage1, atof(argv[3]),atof(argv[4]));
		showImage(originImage1, "Original Image");
		showImage(editedImage1, "Edited Image");
		break;
	default:
		cout << "Please input right command!" << endl;
		return -1;
	}

	waitKey(0);
	return 0;
}

//int main(int argc, char** argv) {
//	Mat originImage1, originImage2, editedImage1, editedImage2;
//
//
//	originImage1 = imread("baboon.jpg", IMREAD_COLOR);		
//
//	editedImage1 = preservedRotateImage(originImage1, 220);
//	showImage(originImage1, "Original Image");
//	showImage(editedImage1, "Edited Image");
//	waitKey(0);
//	return 0;
//}

*/