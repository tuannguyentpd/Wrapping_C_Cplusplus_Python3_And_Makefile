#include "../Headers/OpencvHeaders.h"

#ifndef __LAB03_H__
#define _LAB03_H__

using namespace std;
using namespace cv;

/*Hàm xoay ảnh theo một góc, ảnh sau thực hiện không bị mất nội dung
  Tham số: Ma trận điểm ảnh cần thực hiện, góc quay đo bằng độ
  Trả về: Ma trận điểm ảnh sau thực hiện
*/
Mat preservedRotateImage(Mat origin, int angle);

/*Hàm xoay ảnh theo một góc, ảnh sau thực hiện không thay đổi kích thước so với ảnh ban đầu nhưng có thể mất nội dung
  Tham số: Ma trận điểm ảnh cần thực hiện, góc quay đo bằng độ
  Trả về: Ma trận điểm ảnh sau thực hiện
*/
Mat notPreservedRotateImage(Mat origin, int angle);

/*Hàm phóng to thu nhỏ ảnh trên hai trục x, y
  Tham số: Ma trận điểm ảnh cần thực hiện, hệ số trên trục x, hệ số trên trục y
  Trả về: Ma trận điểm ảnh sau thực hiện
*/
Mat scaleImage(Mat origin, float xScale = 2, float yScale = 2);

/*Hàm hiển thị ảnh ra màn hình
  Tham số: Ma trận điểm ảnh của ảnh cần hiển thị, chuỗi tên của cửa sổ
  Trả về: không có
*/
//void showImage(const Mat &image, string windowName);

#endif // !__LAB03_H__