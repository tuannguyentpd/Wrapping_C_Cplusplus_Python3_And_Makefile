﻿#include "Lab05.h"

using namespace std;
using namespace cv;


void showImage(const Mat &image, string windowName) {
	namedWindow(windowName, WINDOW_AUTOSIZE);
	imshow(windowName, image);
}

/*
bool isGrayscaleImage(Mat image) {
	bool ans = true;
	for (int y = 0; y < image.rows; y++) {
		for (int x = 0; x < image.cols; x++) {						//truy cập từng điểm ảnh trong ma trận
			if (image.at<Vec3b>(y, x)[0] != image.at<Vec3b>(y, x)[1] || image.at<Vec3b>(y, x)[0] != image.at<Vec3b>(y, x)[2]) { //kiểm tra xem các điểm màu có bằng nhau không nếu khác thì cho biến kết quả là false và trả về
				ans = false;
				break;
			}
		}
		if (!ans)
			break;
	}
	return ans;
}
*/

/*
Mat convertToGrayScaleImage(const Mat origin, float redScale, float greenScale, float blueScale) {
	float gray;
	Mat answer = origin.clone();
	for (int y = 0; y < origin.rows; y++)
		for (int x = 0; x < origin.cols; x++) {						//truy cập từng điểm ảnh trong ma trận
			gray = origin.at<Vec3b>(y, x)[0] * redScale + origin.at<Vec3b>(y, x)[1] * greenScale + origin.at<Vec3b>(y, x)[2] * blueScale;		//tính mức xám cho từng bộ điểm màu trong điểm ảnh đó
			for (int color = 0; color < 3; color++)
				answer.at<Vec3b>(y, x)[color] = (uchar)gray;		//áp mức xám vừa tính cho cả ba điểm màu R,G,B
		}
	return answer;
}
*/

Mat PrewittGradientFilter(Mat origin) {
	Mat answer = origin.clone();
	Mat tempoprary = Mat(origin.rows, origin.cols, CV_32F);
	float frac = 9;
	float Gx[3][3] = { {1,0,-1},{1,0,-1},{1,0,-1} };
	float Gy[3][3] = { {1,1,1},{0,0,0},{-1,-1,-1} };
	float result = 0;
	float max = -1, min = 9999999;
	float fx = 0, fy = 0;
	for (int y = 1; y < origin.rows - 1; y++)
		for (int x = 1; x < origin.cols - 1; x++) {
			fx = 0;
			fy = 0;
			for (int i = -1; i <= 1; i++)
				for (int j = -1; j <= 1; j++) {
					fx += Gx[i + 1][j + 1] * origin.at<Vec3b>(y - i, x - j)[0];
					fy += Gy[i + 1][j + 1] * origin.at<Vec3b>(y - i, x - j)[0];
				}
			result = sqrt(((fx*fx) + (fy*fy)) / frac);
			if (result > max)
				max = result;
			if (result < min)
				min = result;
			tempoprary.at<float>(y, x) = result;
		}
	float scale = 255 / max;
	for (int y = 1; y < origin.rows - 1; y++)
		for (int x = 1; x < origin.cols - 1; x++) {
			if (tempoprary.at<float>(y, x) < 10)
				answer.at<Vec3b>(y, x)[0] = 0;
			else
				answer.at<Vec3b>(y, x)[0] = saturate_cast<uchar>(tempoprary.at<float>(y, x)*scale);
			answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
			answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];
		}

	return answer;

}

Mat SobelGradientFilter(Mat origin) {
	Mat answer = origin.clone();
	Mat tempoprary = Mat(origin.rows, origin.cols, CV_32F);
	float frac = 16;
	float Gx[3][3] = { {1,0,-1},{2,0,-2},{1,0,-1} };
	float Gy[3][3] = { {1,2,1},{0,0,0},{-1,-2,-1} };
	float result = 0;
	float max = -1, min = 9999999;
	float fx = 0, fy = 0;
	for (int y = 1; y < origin.rows - 1; y++)
		for (int x = 1; x < origin.cols - 1; x++) {
			fx = 0;
			fy = 0;
			for (int i = -1; i <= 1; i++)
				for (int j = -1; j <= 1; j++) {
					fx += Gx[i + 1][j + 1] * origin.at<Vec3b>(y - i, x - j)[0];
					fy += Gy[i + 1][j + 1] * origin.at<Vec3b>(y - i, x - j)[0];
				}
			result = sqrt(((fx*fx) + (fy*fy)) / frac);
			if (result > max)
				max = result;
			if (result < min)
				min = result;
			tempoprary.at<float>(y, x) = result;
		}
	float scale = 255 / max;
	for (int y = 1; y < origin.rows - 1; y++)
		for (int x = 1; x < origin.cols - 1; x++) {
			if (tempoprary.at<float>(y, x) < 10)
				answer.at<Vec3b>(y, x)[0] = 0;
			else
				answer.at<Vec3b>(y, x)[0] = saturate_cast<uchar>(tempoprary.at<float>(y, x)*scale);
			answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
			answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];
		}

	return answer;

}

Mat FreiChenGradientFilter(Mat origin) {
	Mat answer = origin.clone();
	Mat tempoprary = Mat(origin.rows, origin.cols, CV_32F);
	float frac = (2 + sqrt(2)*(2 + sqrt(2)));
	float Gx[3][3] = { {1,0,-1},{sqrt(2),0,-sqrt(2)},{1,0,-1} };
	float Gy[3][3] = { {1,sqrt(2),1},{0,0,0},{-1,-sqrt(2),-1} };
	float result = 0;
	float max = -1, min = 9999999;
	float fx = 0, fy = 0;
	for (int y = 1; y < origin.rows - 1; y++)
		for (int x = 1; x < origin.cols - 1; x++) {
			fx = 0;
			fy = 0;
			for (int i = -1; i <= 1; i++)
				for (int j = -1; j <= 1; j++) {
					fx += Gx[i + 1][j + 1] * origin.at<Vec3b>(y - i, x - j)[0];
					fy += Gy[i + 1][j + 1] * origin.at<Vec3b>(y - i, x - j)[0];
				}
			result = sqrt(((fx*fx) + (fy*fy)) / frac);
			if (result > max)
				max = result;
			if (result < min)
				min = result;
			tempoprary.at<float>(y, x) = result;
		}
	float scale = 255 / max;
	for (int y = 1; y < origin.rows - 1; y++)
		for (int x = 1; x < origin.cols - 1; x++) {
			if (tempoprary.at<float>(y, x) < 10)
				answer.at<Vec3b>(y, x)[0] = 0;
			else
				answer.at<Vec3b>(y, x)[0] = saturate_cast<uchar>(tempoprary.at<float>(y, x)*scale);
			answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
			answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];
		}

	return answer;

}

Mat ScharrGradientFilter(Mat origin) {
	Mat answer = origin.clone();
	Mat tempoprary = Mat(origin.rows, origin.cols, CV_32F);
	float frac = 256;
	float Gx[3][3] = { {3,0,-3},{10,0,-10},{3,0,-3} };
	float Gy[3][3] = { {3,10,3},{0,0,0},{-3,-10,-3} };
	float result = 0;
	float max = -1, min = 9999999;
	float fx = 0, fy = 0;
	for (int y = 1; y < origin.rows - 1; y++)
		for (int x = 1; x < origin.cols - 1; x++) {
			fx = 0;
			fy = 0;
			for (int i = -1; i <= 1; i++)
				for (int j = -1; j <= 1; j++) {
					fx += Gx[i + 1][j + 1] * origin.at<Vec3b>(y - i, x - j)[0];
					fy += Gy[i + 1][j + 1] * origin.at<Vec3b>(y - i, x - j)[0];
				}
			result = sqrt(((fx*fx) + (fy*fy)) / frac);
			if (result > max)
				max = result;
			if (result < min)
				min = result;
			tempoprary.at<float>(y, x) = result;
		}
	float scale = 255 / max;
	for (int y = 1; y < origin.rows - 1; y++)
		for (int x = 1; x < origin.cols - 1; x++) {
			if (tempoprary.at<float>(y, x) < 10)
				answer.at<Vec3b>(y, x)[0] = 0;
			else
				answer.at<Vec3b>(y, x)[0] = saturate_cast<uchar>(tempoprary.at<float>(y, x)*scale);
			answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
			answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];
		}

	return answer;
}

Mat RobertGradientFilter(Mat origin) {
	Mat answer = origin.clone();
	Mat tempoprary = Mat(origin.rows, origin.cols, CV_32F);
	float frac = 1;
	float Gx[3][3] = { {-1,0,0},{0,1,0},{0,0,0} };
	float Gy[3][3] = { {0,1,0},{-1,0,0},{0,0,0} };
	float result = 0;
	float max = -1, min = 9999999;
	float fx = 0, fy = 0;
	for (int y = 1; y < origin.rows - 1; y++)
		for (int x = 1; x < origin.cols - 1; x++) {
			fx = 0;
			fy = 0;
			for (int i = -1; i <= 1; i++)
				for (int j = -1; j <= 1; j++) {
					fx += Gx[i + 1][j + 1] * origin.at<Vec3b>(y - i, x - j)[0];
					fy += Gy[i + 1][j + 1] * origin.at<Vec3b>(y - i, x - j)[0];
				}
			result = sqrt(((fx*fx) + (fy*fy)) / frac);
			if (result > max)
				max = result;
			if (result < min)
				min = result;
			tempoprary.at<float>(y, x) = result;
		}
	float scale = 255 / max;
	for (int y = 1; y < origin.rows - 1; y++)
		for (int x = 1; x < origin.cols - 1; x++) {
			if (tempoprary.at<float>(y, x) < 10)
				answer.at<Vec3b>(y, x)[0] = 0;
			else
				answer.at<Vec3b>(y, x)[0] = saturate_cast<uchar>(tempoprary.at<float>(y, x)*scale);
			answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
			answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];
		}

	return answer;
}

Mat LaplacianFilter(Mat origin) {
	Mat answer = origin.clone();
	Mat tempoprary = Mat(origin.rows, origin.cols, CV_32F, Scalar(0));
	float LaplaceKernel[3][3] = { {1,1,1},{1,-8,1},{1,1,1} };
	float result = 0;
	for (int y = 1; y < origin.rows - 1; y++)
		for (int x = 1; x < origin.cols - 1; x++) {
			result = 0;
			for (int i = -1; i <= 1; i++)
				for (int j = -1; j <= 1; j++) {
					tempoprary.at<float>(y, x) += LaplaceKernel[i + 1][j + 1] * origin.at<Vec3b>(y - i, x - j)[0];
				}
		}
	bool check;


	for (int y = 1; y < origin.rows - 1; y++)
		for (int x = 1; x < origin.cols - 1; x++) {
			if (tempoprary.at<float>(y, x) < 2 && tempoprary.at<float>(y, x) > -2) {
				if (tempoprary.at<float>(y - 1, x - 1) * tempoprary.at<float>(y + 1, x + 1) < 0) {
					answer.at<Vec3b>(y, x)[0] = saturate_cast<uchar>(abs(tempoprary.at<float>(y - 1, x - 1)) + abs(tempoprary.at<float>(y + 1, x + 1)));
					answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
					answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];
				}
				else if (tempoprary.at<float>(y, x - 1) * tempoprary.at<float>(y, x + 1) < 0) {
					answer.at<Vec3b>(y, x)[0] = saturate_cast<uchar>(abs(tempoprary.at<float>(y, x - 1)) + abs(tempoprary.at<float>(y, x + 1)));
					answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
					answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];
				}
				else if (tempoprary.at<float>(y - 1, x) * tempoprary.at<float>(y + 1, x) < 0) {
					answer.at<Vec3b>(y, x)[0] = saturate_cast<uchar>(abs(tempoprary.at<float>(y - 1, x)) + abs(tempoprary.at<float>(y + 1, x)));
					answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
					answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];
				}
				else if (tempoprary.at<float>(y - 1, x + 1) * tempoprary.at<float>(y + 1, x - 1) < 0) {
					answer.at<Vec3b>(y, x)[0] = saturate_cast<uchar>(abs(tempoprary.at<float>(y - 1, x + 1)) + abs(tempoprary.at<float>(y + 1, x - 1)));
					answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
					answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];
				}
			}
			else if (tempoprary.at<float>(y, x) > 2) {
				if (tempoprary.at<float>(y + 1, x - 1) > -2 && tempoprary.at<float>(y + 1, x) > -2 && tempoprary.at<float>(y + 1, x + 1) > -2 && tempoprary.at<float>(y, x + 1) > -2) {
					answer.at<Vec3b>(y, x)[0] = 0;
					answer.at<Vec3b>(y, x)[1] = 0;
					answer.at<Vec3b>(y, x)[2] = 0;
				}
				else {
					answer.at<Vec3b>(y, x)[0] = saturate_cast<uchar>(tempoprary.at<float>(y, x));
					answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
					answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];
				}
			}
			else
				if (tempoprary.at<float>(y + 1, x - 1) < -2 && tempoprary.at<float>(y + 1, x) < -2 && tempoprary.at<float>(y + 1, x + 1) < -2 && tempoprary.at<float>(y, x + 1) < -2) {
					answer.at<Vec3b>(y, x)[0] = 0;
					answer.at<Vec3b>(y, x)[1] = 0;
					answer.at<Vec3b>(y, x)[2] = 0;
				}
				else {
					answer.at<Vec3b>(y, x)[0] = saturate_cast<uchar>(tempoprary.at<float>(y, x));
					answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
					answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];
				}
		}
	return answer;
}

Mat LaplacianOfGaussianFilter(Mat origin, int size, float sigma) {
	Mat answer = origin.clone();
	if (size % 2 == 0)
		size++;
	Mat LaplaceOfGaussianKernel = Mat(size, size, CV_32F);
	int startIndex = floor(-((float(size) - 1) / 2)), endIndex = floor((float(size) - 1) / 2), center = floor(float(size) / 2);
	float sigmaSquare = sigma * sigma;
	float sum = 0;
	float min = 99999999;
	for (int i = startIndex; i <= endIndex; i++) {
		for (int j = startIndex; j <= endIndex; j++) {
			LaplaceOfGaussianKernel.at<float>(center + i, center + j) = (((i*i + j * j) / (2 * sigmaSquare) - 1) / 3.14159265*sigmaSquare*sigmaSquare)*exp(-(i*i + j * j) / (2 * sigmaSquare));
			/*cout << LaplaceOfGaussianKernel.at<float>(center + i, center + j) << " ";
			if (LaplaceOfGaussianKernel.at<float>(center + i, center + j) > 0 && LaplaceOfGaussianKernel.at<float>(center + i, center + j) < min)
				min = LaplaceOfGaussianKernel.at<float>(center + i, center + j);*/
		}
		//cout << endl;
	}

	for (int i = startIndex; i <= endIndex; i++) {
		for (int j = startIndex; j <= endIndex; j++) {
			LaplaceOfGaussianKernel.at<float>(center + i, center + j) /= LaplaceOfGaussianKernel.at<float>(center, center);
			//cout << LaplaceOfGaussianKernel.at<float>(center + i, center + j) << " ";
		}
		//cout << endl;
	}
	Mat tempoprary = Mat(origin.rows, origin.cols, CV_32F, Scalar(0));
	float result = 0;
	float max = -99999999;

	for (int y = -startIndex; y < origin.rows - endIndex; y++)
		for (int x = -startIndex; x < origin.cols - endIndex; x++) {
			result = 0;
			for (int i = startIndex; i <= endIndex; i++)
				for (int j = startIndex; j <= endIndex; j++) {
					result += LaplaceOfGaussianKernel.at<float>(i + center, j + center)*origin.at<Vec3b>(y - i, x - j)[0];
				}
			if (result > max)
				max = result;
			tempoprary.at<float>(y, x) = result;
		}
	float scale = 1;// = 255 / max;
	cout << max;
	for (int y = -startIndex; y < origin.rows - endIndex; y++)
		for (int x = -startIndex; x < origin.cols - endIndex; x++) {
			answer.at<Vec3b>(y, x)[0] = saturate_cast<uchar>(round(tempoprary.at<float>(y, x)*scale));
			answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
			answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];

		}

	return answer;
}

Mat CannyAlgorithm(Mat origin, float lowerBound, float upperBound) {
	Mat answer;// = origin.clone();
	Mat originCopied = origin.clone();
	GaussianBlur(origin, originCopied, Size(5, 5), 1.4, 1.4, 1);
	Mat tempoprary = Mat(origin.rows, origin.cols, CV_32FC2);
	Mat grad_x, grad_y, abs_x, abs_y;
	Sobel(originCopied, grad_x, CV_32F, 1, 0, 3, 1, 0, BORDER_DEFAULT);
	Sobel(originCopied, grad_y, CV_32F, 0, 1, 3, 1, 0, BORDER_DEFAULT);
	convertScaleAbs(grad_x, abs_x);
	convertScaleAbs(grad_y, abs_y);
	addWeighted(abs_x, 0.5, abs_y, 0.5, 0, answer);
	for (int y = 1; y < origin.rows - 1; y++)
		for (int x = 1; x < origin.cols - 1; x++) {
			tempoprary.at<Vec2f>(y, x)[0] = answer.at<Vec3b>(y, x)[0];
			tempoprary.at<Vec2f>(y, x)[1] = atan(grad_y.at<float>(y, x) / grad_x.at<float>(y, x))*(180 / 3.14159265);
			if (tempoprary.at<Vec2f>(y, x)[1] < 0)
				tempoprary.at<Vec2f>(y, x)[1] = 360 - tempoprary.at<Vec2f>(y, x)[1];
		}

	float alpha = 0;
	for (int y = 1; y < origin.rows - 1; y++)
		for (int x = 1; x < origin.cols - 1; x++) {

			if ((tempoprary.at<Vec2f>(y, x)[1] >= 0 || tempoprary.at<Vec2f>(y, x)[1] < 45) || tempoprary.at<Vec2f>(y, x)[1] >= 180 && tempoprary.at<Vec2f>(y, x)[1] < 225)
			{
				alpha = abs(grad_y.at<float>(y, x) / tempoprary.at<Vec2f>(y, x)[0]);
				if ((1 - alpha)*tempoprary.at<Vec2f>(y, x - 1)[0] + alpha * tempoprary.at<Vec2f>(y + 1, x - 1)[0] > tempoprary.at<Vec2f>(y, x)[0] || (1 - alpha)*tempoprary.at<Vec2f>(y, x + 1)[0] + alpha * tempoprary.at<Vec2f>(y - 1, x + 1)[0] > tempoprary.at<Vec2f>(y, x)[0])
					answer.at<Vec3b>(y, x)[0] = 0;
			}
			else if ((tempoprary.at<Vec2f>(y, x)[1] >= 45 || tempoprary.at<Vec2f>(y, x)[1] < 90) || tempoprary.at<Vec2f>(y, x)[1] >= 225 && tempoprary.at<Vec2f>(y, x)[1] < 270)
			{
				alpha = abs(grad_x.at<float>(y, x) / tempoprary.at<Vec2f>(y, x)[0]);
				if ((1 - alpha)*tempoprary.at<Vec2f>(y - 1, x)[0] + alpha * tempoprary.at<Vec2f>(y - 1, x + 1)[0] > tempoprary.at<Vec2f>(y, x)[0] || (1 - alpha)*tempoprary.at<Vec2f>(y + 1, x)[0] + alpha * tempoprary.at<Vec2f>(y + 1, x - 1)[0] > tempoprary.at<Vec2f>(y, x)[0])
					answer.at<Vec3b>(y, x)[0] = 0;
			}
			else if ((tempoprary.at<Vec2f>(y, x)[1] >= 90 || tempoprary.at<Vec2f>(y, x)[1] < 135) || tempoprary.at<Vec2f>(y, x)[1] >= 270 && tempoprary.at<Vec2f>(y, x)[1] < 315)
			{
				alpha = abs(grad_x.at<float>(y, x) / tempoprary.at<Vec2f>(y, x)[0]);
				if ((1 - alpha)*tempoprary.at<Vec2f>(y - 1, x)[0] + alpha * tempoprary.at<Vec2f>(y - 1, x - 1)[0] > tempoprary.at<Vec2f>(y, x)[0] || (1 - alpha)*tempoprary.at<Vec2f>(y + 1, x)[0] + alpha * tempoprary.at<Vec2f>(y + 1, x + 1)[0] > tempoprary.at<Vec2f>(y, x)[0])
					answer.at<Vec3b>(y, x)[0] = 0;
			}
			else if ((tempoprary.at<Vec2f>(y, x)[1] >= 135 || tempoprary.at<Vec2f>(y, x)[1] < 180) || tempoprary.at<Vec2f>(y, x)[1] >= 315 && tempoprary.at<Vec2f>(y, x)[1] <= 360)
			{
				alpha = abs(grad_y.at<float>(y, x) / tempoprary.at<Vec2f>(y, x)[0]);
				if ((1 - alpha)*tempoprary.at<Vec2f>(y, x - 1)[0] + alpha * tempoprary.at<Vec2f>(y - 1, x - 1)[0] > tempoprary.at<Vec2f>(y, x)[0] || (1 - alpha)*tempoprary.at<Vec2f>(y, x + 1)[0] + alpha * tempoprary.at<Vec2f>(y + 1, x + 1)[0] > tempoprary.at<Vec2f>(y, x)[0])
					answer.at<Vec3b>(y, x)[0] = 0;
			}
		}
	//for (int y = 1; y < origin.rows - 1; y++)
	//	for (int x = 1; x < origin.cols - 1; x++) {
	//		//answer.at<Vec3b>(y, x)[0] = tempoprary.at<Vec2f>(y, x)[0];
	//		answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
	//		answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];
	//	}
	//showImage(answer, "non_maximal");
	for (int y = 1; y < origin.rows - 1; y++)
		for (int x = 1; x < origin.cols - 1; x++) {
			if (answer.at<Vec3b>(y, x)[0] >= upperBound) {
				answer.at<Vec3b>(y, x)[0] = 255;
				continue;
			}
			else if (answer.at<Vec3b>(y, x)[0] < lowerBound) {
				answer.at<Vec3b>(y, x)[0] = 0;
				continue;
			}
			else {
				bool check = false;
				for (int i = -1; i <= 1; i++)
					for (int j = -1; j <= 1; j++)
						if (check == false && answer.at<Vec3b>(y + i, x + j)[0] >= upperBound) {
							answer.at<Vec3b>(y, x)[0] = 255;
							check = true;
							continue;
						}
				if (!check)
					answer.at<Vec3b>(y, x)[0] = 0;
			}
		}

	for (int y = 1; y < origin.rows - 1; y++)
		for (int x = 1; x < origin.cols - 1; x++) {
			//answer.at<Vec3b>(y, x)[0] = tempoprary.at<Vec2f>(y, x)[0];
			answer.at<Vec3b>(y, x)[1] = answer.at<Vec3b>(y, x)[0];
			answer.at<Vec3b>(y, x)[2] = answer.at<Vec3b>(y, x)[0];
		}
	//cout << origin.rows << " " << origin.cols;
	//showImage(origin, "test");
	//GaussianBlur(answer, answer, Size(3, 3), 0.6, 0.6, 1);
	return answer;
}




/*
#define NUMBER_COMMAND 7

int main(int argc, char** argv) {
	string commandList[NUMBER_COMMAND] = { "--gra-sobel","--gra-prewitt","--gra-scharr","--gra-roberts","--laplacian","--log","--canny" };			//những lệnh hỗ trợ
	Mat originImage1, originImage2, editedImage1, editedImage2;			//(1) khởi tạo đối tượng Matrix để xử lý dữ liệu ảnh dưới dạng các ma trận điểm ảnh
	int command;

	if (argc < 3) {
		cout << "Wrong argument number input!" << endl;
		return -1;
	}


	originImage1 = imread(argv[1], IMREAD_COLOR);		//(2) hàm imread tiến hành đọc một file ảnh với đường dẫn được nhập vào từ command line và trả về ảnh đó dưới dạng ma trận điểm ảnh Mat

	if (!originImage1.data)
	{
		cout << "Can't open image" << std::endl;
		return -1;
	}

	for (command = 0; command < NUMBER_COMMAND; command++) {								//tiến hành việc kiểm tra lệnh người dùng nhập vào
		if (strcmp(commandList[command].c_str(), strlwr(argv[2])) == 0)
			break;
	}
	showImage(originImage1, "Original Image");
	originImage1 = convertToGrayScaleImage(originImage1);

	switch (command) {
	case 0:
		editedImage1 = SobelGradientFilter(originImage1);
		
		showImage(editedImage1, "Edited Image");
		break;
	case 1:
		editedImage1 = PrewittGradientFilter(originImage1);
		showImage(editedImage1, "Edited Image");
		break;
	case 2:
		editedImage1 = ScharrGradientFilter(originImage1);
		showImage(editedImage1, "Edited Image");
		break;
	case 3:
		editedImage1 = RobertGradientFilter(originImage1);
		showImage(editedImage1, "Edited Image");
		break;
	case 4:
		editedImage1 = LaplacianFilter(originImage1);
		showImage(editedImage1, "Edited Image");
		break;
	case 5:
		if (argc < 5) {
			cout << "Wrong argument number input!" << endl;
			return -1;
		}
		editedImage1 = LaplacianOfGaussianFilter(originImage1,atoi(argv[3]),atof(argv[4]));
		showImage(editedImage1, "Edited Image");
		break;
	case 6:
		if (argc < 5) {
			cout << "Wrong argument number input!" << endl;
			return -1;
		}
		editedImage1 = CannyAlgorithm(originImage1,atof(argv[3]),atof(argv[4]));
		showImage(editedImage1, "Edited Image");
		break;

	default:
		cout << "Please input right command!" << endl;
		return -1;
	}

	waitKey(0);
	return 0;
}

//int main(int argc, char** argv) {
//	Mat originImage1, originImage2, editedImage1, editedImage2;
//
//
//	originImage1 = imread("test.png", IMREAD_COLOR);
//	if (!originImage1.data)
//	{
//		cout << "Can't open image" << std::endl;
//		return -1;
//	}
//	originImage1 = convertToGrayScaleImage(originImage1);
//
//	//cout << acos(0);
//	cout << originImage1.rows << " " << originImage1.cols << endl;
//	//showImage(originImage1, "testest");
//	Mat grad_x, grad_y, abs_grad_x, abs_grad_y;
//	editedImage1 = LaplacianOfGaussianFilter(originImage1);
//	// editedImage1 = SobelGradientFilter(originImage1);
//	//Laplacian(originImage1,editedImage2,CV_16S,3,1,0,BORDER_DEFAULT);
//	//Sobel(originImage1, grad_x, CV_16S, 1, 0, 3, 1, 0, BORDER_DEFAULT);
//	//convertScaleAbs(editedImage2, editedImage2);
//	//Laplacian(originImage1, editedImage2, CV_16S, 3, 1, 0, BORDER_DEFAULT);
//	/// Gradient Y
//	//Scharr( src_gray, grad_y, ddepth, 0, 1, scale, delta, BORDER_DEFAULT );
//	//Sobel(originImage1, grad_y, CV_16S, 0, 1, 3, 1, 0, BORDER_DEFAULT);
//	//convertScaleAbs(grad_y, abs_grad_y);
//	Canny(originImage1, editedImage2, 118, 128);
//	/// Total Gradient (approximate)
//	//addWeighted(abs_grad_x, 0.5, abs_grad_y, 0.5, 0, editedImage2);
//
//	//imshow(window_name, grad);
//	//GaussianBlur(originImage1, editedImage2, Size(3, 5), 1, 1);
//	//cout << "why?";
//	//editedImage2 = FreiChenGradientFilter(convertToGrayScaleImage(originImage1));
//	showImage(originImage1, "Original Image");
//	showImage(editedImage1, "Edited Image");
//	showImage(editedImage2, "OpenCV");
//	//showImage(abs_grad_x, "OpenCV");
//
//
//	waitKey(0);
//	return 0;
//}
*/