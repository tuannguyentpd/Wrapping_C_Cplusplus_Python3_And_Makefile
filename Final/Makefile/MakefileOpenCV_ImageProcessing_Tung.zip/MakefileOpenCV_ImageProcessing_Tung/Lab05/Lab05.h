#include "../Headers/OpencvHeaders.h"

#ifndef __LAB05_H__
#define __LAB05_H__

using namespace std;
using namespace cv;

/*Hàm hiển thị ảnh ra màn hình
  Tham số: Ma trận điểm ảnh của ảnh cần hiển thị, chuỗi tên của cửa sổ
  Trả về: không có
*/
void showImage(const Mat &image, string windowName);

/*Hàm kiểm tra ma trận ảnh có phải là ảnh trắng đen hay không
  Tham số: Ma trận điểm ảnh cần kiểm tra
  Trả về: false nếu là ảnh màu, true nếu là ảnh trắng đen
*/
//bool isGrayscaleImage(Mat image);

/*Hàm chuyển đổi ảnh màu sang trắng đen
  Tham số: Ma trận điểm ảnh cần chuyển đổi, tỷ lệ màu R,G,B khi tiến hành chuyển (ở đây mặc định các tham số này dựa trên luminosity method)
  Trả về: Ma trận ảnh đã chuyển đổi
*/
//Mat convertToGrayScaleImage(const Mat origin, float redScale, float greenScale, float blueScale);

/*Hàm áp dụng bộ lọc Prewitt vào ảnh để phát hiện biên cạnh
  Tham số: ma trận ảnh đầu vào
  Trả về: Ma trận ảnh đã chuyển đổi
*/
Mat PrewittGradientFilter(Mat origin);

/*Hàm áp dụng bộ lọc Sobel vào ảnh để phát hiện biên cạnh
  Tham số: ma trận ảnh đầu vào
  Trả về: Ma trận ảnh đã chuyển đổi
*/
Mat SobelGradientFilter(Mat origin);

/*Hàm áp dụng bộ lọc FreiChen vào ảnh để phát hiện biên cạnh
  Tham số: ma trận ảnh đầu vào
  Trả về: Ma trận ảnh đã chuyển đổi
*/
Mat FreiChenGradientFilter(Mat origin);

/*Hàm áp dụng bộ lọc Scharr vào ảnh để phát hiện biên cạnh
  Tham số: ma trận ảnh đầu vào
  Trả về: Ma trận ảnh đã chuyển đổi
*/
Mat ScharrGradientFilter(Mat origin);

/*Hàm áp dụng bộ lọc Robert vào ảnh để phát hiện biên cạnh
  Tham số: ma trận ảnh đầu vào
  Trả về: Ma trận ảnh đã chuyển đổi
*/
Mat RobertGradientFilter(Mat origin);

/*Hàm áp dụng bộ lọc Laplacian vào ảnh để phát hiện biên cạnh
  Tham số: ma trận ảnh đầu vào
  Trả về: Ma trận ảnh đã chuyển đổi
*/
Mat LaplacianFilter(Mat origin);

/*Hàm áp dụng bộ lọc Laplacian of Gaussian vào ảnh để phát hiện biên cạnh
  Tham số: ma trận ảnh đầu vào
  Trả về: Ma trận ảnh đã chuyển đổi
*/
Mat LaplacianOfGaussianFilter(Mat origin, int size, float sigma);

/*Hàm áp dụng thuật toán Canny vào ảnh để phát hiện biên cạnh
  Tham số: ma trận ảnh đầu vào, ngưỡng trên cho biên cạnh mạnh, ngưỡng dưới cho biên cạnh yếu
  Trả về: Ma trận ảnh đã chuyển đổi
*/
Mat CannyAlgorithm(Mat origin, float lowerBound, float upperBound);

#endif // !__LAB05_H__