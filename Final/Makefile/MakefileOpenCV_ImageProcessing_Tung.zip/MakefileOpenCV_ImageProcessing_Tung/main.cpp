#include "Headers/OpencvHeaders.h"
#include "Lab01/Lab01.h"
#include "Lab01/RGBHistogram.h"
#include "Lab02/Lab02.h"
#include "Lab02/Histogram.h"
#include "Lab03/Lab03.h"
#include "Lab04/Lab04.h"
#include "Lab05/Lab05.h"

using namespace std;
using namespace cv;

#include <ctype.h>
#include <string.h>

char *strlwr(char *str)
{
  unsigned char *p = (unsigned char *)str;

  while (*p) {
     *p = tolower((unsigned char)*p);
      p++;
  }

  return str;
}

#define NUMBER_COMMAND 12
int main(int agrc, char** agrv) {
	if (agrc <= 1)
		return -1;
	string windowName1 = "Origin Image", windowName2 = "Edited Image", windowName3="HistogramImage1", windowName4="HistogramImage2";
	string commandList[NUMBER_COMMAND] = { "--g","--b","--c","--n","--lt","--gt","--hi","--cmphi","--hiqc","--hiqg","--cphiqc","--cphiqg" };			//những lệnh hỗ trợ
	Mat originImage1, originImage2, editedImage1, editedImage2;			//(1) khởi tạo đối tượng Matrix để xử lý dữ liệu ảnh dưới dạng các ma trận điểm ảnh
	int command;
	RGB_Histogram hist1, hist2;

	for (command = 0; command < NUMBER_COMMAND; command++) {								//tiến hành việc kiểm tra lệnh người dùng nhập vào
		if (strcmp(commandList[command].c_str(), strlwr(agrv[1])) == 0)
			break;
	}
	originImage1 = imread(agrv[2], IMREAD_COLOR);		//(2) hàm imread tiến hành đọc một file ảnh với đường dẫn được nhập vào từ command line và trả về ảnh đó dưới dạng ma trận điểm ảnh Mat
	cout << agrv[2] << endl;

	if (!originImage1.data)
	{
		cout << "Can't open the image" << endl;
		return -1;
	}

	if (agrc < 3) {
		cout << "Please input command!" << endl;
		return -1;
	}
	
	switch (command) {								//xử lý các lệnh nhập vào
	case 0:
		if (isGrayscaleImage(originImage1)) {
			cout << "This function is only use for color image!" << endl;
		}
		editedImage1 = convertToGrayScaleImage(originImage1);
		break;
	case 1: 
		editedImage1 = adjustBrightness(originImage1, atoi(agrv[3])); break;
	case 2: 
		editedImage1 = adjustConstrast(originImage1, atof(agrv[3])); break;
	case 3:
		editedImage1 = convertToNegativeImage(originImage1);
		break;
	case 4:
		editedImage1 = LogarithmOperator(originImage1,atof(agrv[3])); break;
	case 5:
		editedImage1 = gammaCorrection(originImage1,atof(agrv[3]),atof(agrv[4])); break;
	case 6:
		hist1=RGB_Histogram(originImage1);
		editedImage1 = hist1.drawHistogramToAnImage();
		break;
	case 7:
		originImage2 = imread(agrv[3], IMREAD_COLOR);
		hist1 = RGB_Histogram(originImage1);
		hist2 = RGB_Histogram(originImage2);
		editedImage1 = hist1.drawHistogramToAnImage();
		editedImage2 = hist2.drawHistogramToAnImage();
		cout << hist1.compare(hist2);
		break;
	case 8:
		hist1 = RGB_Histogram(originImage1, atoi(agrv[3]));
		editedImage1 = hist1.drawHistogramToAnImage();
		break;
	case 9:
		hist1 = RGB_Histogram(originImage1, atoi(agrv[3]));
		editedImage1 = hist1.drawHistogramToAnImage();
		break;
	case 10:
		originImage2 = imread(agrv[3], IMREAD_COLOR);
		hist1 = RGB_Histogram(originImage1,atoi(agrv[4]));
		hist2 = RGB_Histogram(originImage2,atoi(agrv[4]));
		editedImage1 = hist1.drawHistogramToAnImage();
		editedImage2 = hist2.drawHistogramToAnImage();
		cout << hist1.compare(hist2);
		break;
	case 11:
		originImage2 = imread(agrv[3], IMREAD_COLOR);
		hist1 = RGB_Histogram(originImage1, atoi(agrv[4]));
		hist2 = RGB_Histogram(originImage2, atoi(agrv[4]));
		editedImage1 = hist1.drawHistogramToAnImage();
		editedImage2 = hist2.drawHistogramToAnImage();
		cout << hist1.compare(hist2);
		break;

	default: cout << "Please input right command!" << endl; return -1;
	}

	switch (command) {								//tiến hành show kết quả dựa trên lệnh
	case 0: case 1: case 2:case 3:case 4:case 5:
		namedWindow(windowName1, WINDOW_AUTOSIZE);
		namedWindow(windowName2, WINDOW_AUTOSIZE);
		imshow(windowName1, originImage1);
		imshow(windowName2, editedImage1);
		break;
	case 6: case 8: case 9:
		windowName1 = "Image"; windowName2 = "Histogram";
		namedWindow(windowName1, WINDOW_AUTOSIZE);
		namedWindow(windowName2, WINDOW_AUTOSIZE);
		imshow(windowName1, originImage1);
		imshow(windowName2, editedImage1);
		break;
	case 7:case 10: case 11:
		windowName1 = "Image1"; windowName2 = "Histogram Image1"; windowName3 = "Image2"; windowName4 = "Histogram Image2";
		namedWindow(windowName1, WINDOW_AUTOSIZE);
		namedWindow(windowName2, WINDOW_AUTOSIZE);
		namedWindow(windowName3, WINDOW_AUTOSIZE);
		namedWindow(windowName4, WINDOW_AUTOSIZE);
		imshow(windowName1, originImage1);
		imshow(windowName3, originImage2);
		imshow(windowName2, editedImage1);
		imshow(windowName4, editedImage2);
		break;
	}
	
	waitKey(0);
	return 0;
}