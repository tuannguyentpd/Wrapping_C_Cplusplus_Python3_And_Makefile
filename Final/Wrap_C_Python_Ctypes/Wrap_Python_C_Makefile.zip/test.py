import os

#os.system('gcc -o matrix.so -shared -fPIC matrix.c')
#os.system('gcc -o array.so -shared -fPIC array.c')
#os.system('gcc -o operation.so -shared -fPIC operation.c')
#os.system('make')
os.system('export LD_LIBRARY_PATH=.')

import time
from ctypes import cdll
import ctypes
from ctypes import *
import numpy as np
import random

''' Dung thu vien dong C '''

matrix_lib = cdll.LoadLibrary("matrix.so")
multi_matrix = matrix_lib.matrix_Multi
multi_matrix.argtypes = [ctypes.POINTER(ctypes.POINTER(ctypes.c_int)), ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.POINTER(ctypes.c_int)), ctypes.c_int, ctypes.c_int]
multi_matrix.restype = ctypes.POINTER(ctypes.POINTER(ctypes.c_int))
print_matrix = matrix_lib.print_Matrix
print_matrix.argtypes = [ctypes.POINTER(ctypes.POINTER(ctypes.c_int)), ctypes.c_int, ctypes.c_int]
random_matrix = matrix_lib.random_Matrix
random_matrix.argtypes = [ctypes.POINTER(ctypes.POINTER(ctypes.c_int)), ctypes.c_int, ctypes.c_int]
random_matrix.restype = ctypes.POINTER(ctypes.POINTER(ctypes.c_int))

array_lib = cdll.LoadLibrary("array.so")
sort_array = array_lib.sortArray
sort_array.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_int]
print_array = array_lib.printArray
print_array.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_int]
random_array = array_lib.randomArray
random_array.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_int]

operation_lib = cdll.LoadLibrary("operation.so")
sum_int = operation_lib.sum
minus_int = operation_lib.minus
mul_int = operation_lib.mul
div_int = operation_lib.div_
mod_int = operation_lib.mod



def print_sum(a, b):
    print("%d + %d = %d"%(a, b, sum_int(a, b)))
          
def print_minus(a, b):
    print("%d - %d = %d"%(a, b, minus_int(a, b)))
              
def print_mul(a, b):
    print("%d * %d = %d"%(a, b, mul_int(a, b)))
              
def print_div(a, b):
    print("%d / %d = %d"%(a, b, div_int(a, b)))
              
def print_mod(a, b):
    print("%d mod %d = %d"%(a, b, mod_int(a, b))) 
    
def print_cal_CLib(a, b):
    print_sum(a, b)
    print_minus(a, b)
    print_mul(a, b)
    print_div(a, b)
    print_mod(a, b)
    
def print_sum_py(a, b):
    print("%d + %d = %d"%(a, b, a+b))
          
def print_minus_py(a, b):
    print("%d - %d = %d"%(a, b, a-b))
              
def print_mul_py(a, b):
    print("%d * %d = %d"%(a, b, a*b))
              
def print_div_py(a, b):
    print("%d / %d = %d"%(a, b, a/b))
              
def print_mod_py(a, b):
    print("%d mod %d = %d"%(a, b, a%b)) 
    
def print_cal_pyDev(a, b):
    print_sum_py(a, b)
    print_minus_py(a, b)
    print_mul_py(a, b)
    print_div_py(a, b)
    print_mod_py(a, b)   



MAX_ = 10000
def randomMatrix_pyDev(a, n, m):
    for i in range(n):
        for j in range(m):
            a[i][j] = random.randrange(MAX_)

def multi_matrix_pyDev(a, na, ma, b, nb, mb):
    pass

def testMultiMatrix():
    na = ma = 3
    nb = 3
    mb = 2

    #Multi Matrix - python code
    start_time = time.time()
    finish_time = time.time()
    runtime_py = finish_time - start_time
    print("Python_MultiMatrix: Program excuted in %s seconds ---" % (runtime_py))    

    #Multi matrix python wrapped C
    na_CLib = ctypes.c_int(na)
    ma_CLib = ctypes.c_int(ma)
    nb_CLib = ctypes.c_int(nb)
    mb_CLib = ctypes.c_int(mb)
    matrixA = ((ctypes.c_int * ma_CLib.value) * na_CLib.value)()
    matrixB = ((ctypes.c_int * mb_CLib.value) * nb_CLib.value)()
    matrixA_CLib = cast(matrixA, ctypes.POINTER(ctypes.POINTER(ctypes.c_int)))
    print(matrixA_CLib)
    matrixB_CLib = cast(matrixB, ctypes.POINTER(ctypes.POINTER(ctypes.c_int)))
    print(matrixB_CLib)
    random_matrix(matrixA_CLib, na_CLib, ma_CLib)
    print_matrix(matrixA_CLib, na_CLib, ma_CLib)
    random_matrix(matrixB_CLib, nb_CLib, mb_CLib)
    print_matrix(matrixB_CLib, nb_CLib, mb_CLib)
    start_time = time.time()
    multi_matrix(matrixA_CLib, na_CLib, ma_CLib, matrixB_CLib, nb_CLib, mb_CLib)
    finish_time = time.time()
    runtime_c = finish_time - start_time
    print("C_MultiMatrix: Program excuted in %s seconds ---" % (runtime_c))
    
    print("Ctypes nhanh hon Python: %.5f lan"%(runtime_py/runtime_c))


       
def sort_arr_CLib(a, n):
    sort_array(a, n)

def sort_arr_pyDev(a, n):
    if n<2: return
    for i in range(n-1):
        for j in range(1, n):
            if a[i]>a[j]:
                temp = a[i]
                a[i] = a[j]
                a[j] = temp
    
def testSortArray():
    number = 100
    #Sort Array - python code
    n_pyDev = number
    arr_pyDev = np.random.randint(10000, size=n_pyDev)
    start_time = time.time()
    sort_arr_pyDev(arr_pyDev, n_pyDev)
    finish_time = time.time()
    runtime_py = finish_time - start_time
    print("Python_InterchangeSort: Program excuted in %s seconds ---" % (runtime_py))    

    #Sort Array python wrapped C
    n_CLib = ctypes.c_int(number)
    arr_CLib = (ctypes.c_int * n_CLib.value)()
    random_array(arr_CLib, n_CLib)
    cast(arr_CLib, ctypes.POINTER(ctypes.c_int))
    start_time = time.time()
    sort_arr_CLib(arr_CLib, n_CLib)
    finish_time = time.time()
    runtime_c = finish_time - start_time
    print("C_InterchangeSort: Program excuted in %s seconds ---" % (runtime_c))
    
    print("Ctypes nhanh hon Python: %.5f lan"%(runtime_py/runtime_c))   
    


if __name__=='__main__':
    #testSortArray()
    testMultiMatrix()