#include <stdio.h>
#include<malloc.h>
#include<time.h>
#include<stdlib.h>

#include "loop.h"

/*************     Test Functions     ************/
int sum(int a, int b){
    return a+ b;
}

int minus(int a, int b){
    return a-b;
}

int mul(int a, int b){
    return a*b;
}

int div_(int a, int b){
    return a/b;
}

int mod(int a, int b){
    return a%b;
}


/*************     Dynamic     ************/
void allocalMemOfArr(int *a, int n, int m){
    a = (int*)malloc(n*m*sizeof(int*));
}

int* random_Matrix(int *a, int n, int m){
    for (int i=0;i<n;++i){
        for (int j=0;j<m;++j){
            a[i*m+j] = rand() % MAX_NUMBER;
        }
    }

    return a;
}

int print_Matrix(int *a, int n, int m){
    printf("Matrix data:\n");
    for (int i=0;i<n;++i){
        for (int j=0;j<m;++j){
            printf("%d\t", a[i*m+j]);
        }
        printf("\n");
    }

    return 0;
}

int* matrix_Multi(int *a, int na, int ma, int *b, int nb, int mb){
    if (ma!=nb){
        printf("ma not equal nb!\n");
        return NULL;
    }

    int i, row, col;

    int *result=(int*)malloc(na*mb*sizeof(int*));

    for (row=0;row<na;++row){
        for (col=0;col<mb;++col){
            result[row*mb+col] = 0;
            for(i=0;i<ma;++i){
                result[row*mb+col] += a[row*ma+i]*b[i*mb+col];
            }
        }
    }

    return result;
}


/*************     Static     ************/
void random_Matrix_s(int *a[], int n, int m){
    for (int i=0;i<n;++i){
        for (int j=0;j<m;++j){
            a[i][j] = rand() % MAX_NUMBER;
        }
    }
}

void print_Matrix_s(int *a[], int n, int m){
    printf("Matrix data:\n");
    for (int i=0;i<n;++i){
        for (int j=0;j<m;++j){
            printf("%d\t", a[i][j]);
        }
        printf("\n");
    }
}

void matrix_Multi_s(int *a[], int na, int ma, int *b[], int nb, int mb){
    if (ma!=nb){
        printf("ma not equal nb!\n");
    }

    int i, row, col;

    int **result=(int**)malloc(na*sizeof(int*));
    for (i=0;i<na;++i){
        result[i] = (int*)malloc(mb*sizeof(int));
    }

    for (row=0;row<na;++row){
        for (col=0;col<mb;++col){
            result[row][col] = 0;
            for(i=0;i<ma;++i){
                result[row][col] += a[row][i]*b[i][col];
            }
        }

    }
}
