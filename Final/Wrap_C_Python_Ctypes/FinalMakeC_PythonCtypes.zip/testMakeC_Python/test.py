import time
from ctypes import cdll
import ctypes
import os
import sys

os.system("export LD_LIBRARY_PATH=.")

''' Dung thu vien dong C '''
matrix_lib = cdll.LoadLibrary('multi_matrix.so')
multi_matrix = matrix_lib.matrix_Multi
multi_matrix.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_int), ctypes.c_int, ctypes.c_int]
print_matrix = matrix_lib.print_Matrix
print_matrix.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_int, ctypes.c_int]
random_matrix = matrix_lib.random_Matrix
random_matrix.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_int, ctypes.c_int]
allocal_matrix = matrix_lib.allocalMemOfArr
allocal_matrix.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_int, ctypes.c_int]

sum_int = matrix_lib.sum
minus_int = matrix_lib.minus
mul_int = matrix_lib.mul
div_int = matrix_lib.div_
mod_int = matrix_lib.mod

def print_sum(a, b):
    print("%d + %d = %d"%(a, b, sum_int(a, b)))
          
def print_minus(a, b):
    print("%d - %d = %d"%(a, b, minus_int(a, b)))
              
def print_mul(a, b):
    print("%d * %d = %d"%(a, b, mul_int(a, b)))
              
def print_div(a, b):
    print("%d / %d = %d"%(a, b, div_int(a, b)))
              
def print_mod(a, b):
    print("%d mod %d = %d"%(a, b, mod_int(a, b))) 

def mulMatrix(a, na, ma, b, nb, mb):
    random_matrix(a, na, ma)
    #print_matrix(a, na, ma)
    random_matrix(b, nb, mb)
    #print_matrix(b, nb, mb)
    
    print_matrix(multi_matrix(a, na, ma, b, nb, mb), na, mb)
    
def print_cal_CLib(a, b):
    print_sum(a, b)
    print_minus(a, b)
    print_mul(a, b)
    print_div(a, b)
    print_mod(a, b)
    
    
''' Dung code python '''

def print_sum_py(a, b):
    print("%d + %d = %d"%(a, b, a+b))
          
def print_minus_py(a, b):
    print("%d - %d = %d"%(a, b, a-b))
              
def print_mul_py(a, b):
    print("%d * %d = %d"%(a, b, a*b))
              
def print_div_py(a, b):
    print("%d / %d = %d"%(a, b, a/b))
              
def print_mod_py(a, b):
    print("%d mod %d = %d"%(a, b, a%b)) 
    
def print_cal_pyDev(a, b):
    print_sum_py(a, b)
    print_minus_py(a, b)
    print_mul_py(a, b)
    print_div_py(a, b)
    print_mod_py(a, b)   

def multi_matrix_pyDev(a, b):
    na = len(a)
    #print(na)
    ma = len(a[0])
    #print(ma)
    nb = len(b)
    #print(nb);
    mb = len(b[0])
    #print(mb);
    result = [[0]*mb]*na
    for row in range(na):
        for col in range(mb):
            result[row][col] = 0;
            for i in range(ma):
                result[row][col] += a[row][i] * b[i][col]
    return result

def multi_matrix_pyDev_v1(a, na, ma, b, nb, mb):
    result = [0]*na*mb
    for row in range(na):
        #print(row)
        for col in range(mb):
            result[row*mb+col] = 0;
            for i in range(ma):
                result[row*mb+col] += a[row*ma+i] * b[i*mb+col]
    return result


from random import randrange
import numpy as np
def testMultiMatrix():
    na = 1000
    ma = 1000
    nb = 1000
    mb = 1000

    #Multi Matrix - python code
    a = []
    b = []
    for i in range(na):
        for j in range(ma):
            a.append(randrange(1000))
    for i in range(nb):
        for j in range(mb):
            b.append(randrange(1000))

    print("Memmory: %d"%sys.getsizeof(a))

    start_time = time.time()
    multi_matrix_pyDev_v1(a, na, ma, b, nb, mb)
    finish_time = time.time()
    runtime_py = finish_time - start_time
    print("Python_MultiMatrix: Program excuted in %s seconds ---" % (runtime_py))    

    #Multi matrix python wrapped C
    na_CLib = ctypes.c_int(na)
    ma_CLib = ctypes.c_int(ma)
    nb_CLib = ctypes.c_int(nb)
    mb_CLib = ctypes.c_int(mb)
    matrixA = (ctypes.c_int * na_CLib.value * ma_CLib.value)()
    matrixB = (ctypes.c_int * nb_CLib.value * mb_CLib.value)()
    matrixA_CLib = ctypes.cast(matrixA, ctypes.POINTER(ctypes.c_int))
    matrixB_CLib = ctypes.cast(matrixB, ctypes.POINTER(ctypes.c_int))
    random_matrix(matrixA_CLib, na_CLib, ma_CLib)
    random_matrix(matrixB_CLib, nb_CLib, mb_CLib)

    print("Memmory: %d"%sys.getsizeof(matrixA))

    start_time = time.time()
    multi_matrix(matrixA_CLib, na_CLib, ma_CLib, matrixB_CLib, nb_CLib, mb_CLib)
    finish_time = time.time()
    runtime_c = finish_time - start_time
    print("C_MultiMatrix: Program excuted in %s seconds ---" % (runtime_c))
    
    print("Ctypes nhanh hon Python: %.5f lan"%(runtime_py/runtime_c))

    #Multi Matrix - python - numpy
    a_np = np.random.randint(1000, size=(na, ma))
    b_np = np.random.randint(1000, size=(nb, mb))

    print("Memmory: %d"%sys.getsizeof(matrixA))

    start_time = time.time()
    res = np.dot(a_np, b_np)
    finish_time = time.time()
    runtime_numpy = finish_time - start_time
    print("Numpy_MultiMatrix: Program excuted in %s seconds ---" % (runtime_numpy))

    print("Numpy nhanh hon C: %.5f lan"%(runtime_c/runtime_numpy))
   
if __name__=='__main__':
    testMultiMatrix()