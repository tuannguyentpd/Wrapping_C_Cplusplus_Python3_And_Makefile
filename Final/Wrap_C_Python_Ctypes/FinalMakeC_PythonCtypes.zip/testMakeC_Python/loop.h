#ifndef MAX_NUMBER
#define MAX_NUMBER 1000
#endif

#ifndef __LOOP_H__
#define __LOOP_H__

int* matrix_Multi(int *a, int na, int ma, int *b, int nb, int mb);
int print_Matrix(int *a, int n, int m);
int* random_Matrix(int *a, int n, int m);
void allocalMemOfArr(int *a, int n, int m);

void matrix_Multi_s(int *a[], int na, int ma, int *b[], int nb, int mb);
void print_Matrix_s(int *a[], int n, int m);
void random_Matrix_s(int *a[], int n, int m);

int sum(int a, int b);
int minus(int a, int b);
int mul(int a, int b);
int div_(int a, int b);
int mod(int a, int b);

#endif // !__LOOP_H__
