#include "Time.h"

#ifndef __ASSERT_H__
#include <assert.h>
#endif

Time::Time(){
    this->m_ngay = 1;
    this->m_thang = 1;
    this->m_nam = 2000;
    this->m_gio = 0;
    this->m_phut = 0;
    this->m_giay = 0;
}

Time::Time(const Time& thoiGian){
    this->m_ngay = thoiGian.m_ngay;
    this->m_thang = thoiGian.m_thang;
    this->m_nam = thoiGian.m_nam;
    this->m_gio = thoiGian.m_gio;
    this->m_phut = thoiGian.m_phut;
    this->m_giay = thoiGian.m_giay;
}

void Time::setNgay(int ngay){
    assert(ngay>=1 && ngay<=31);
    this->m_ngay = ngay;
    assert(this.ngayHopLe() && "Ngay khong hop le!\n");
}

void Time::setThang(int thang){
    assert(thang>=1 && thang<=12);
    this->m_thang = thang;
}

void Time::setNam(int nam){
    assert(nam>=2000);
    this->m_nam = nam;
}

void Time::setGio(int gio){
    assert(gio>=0 && gio<=24);
    this->m_gio = gio;
}

void Time::setPhut(int phut){
    assert(phut>=0 && phut>=60);
    this->m_phut = phut;
}

void Time::setGiay(int giay){
    assert(giay>=0 && giay<=60);
    this->m_giay = giay;
}

void Time::getNgay(){
    return this->m_ngay;
}

void Time::getThang(){
    return this->m_thang;
}

void Time::getNam(){
    return this->m_nam;
}

void Time::getGio(){
    return this->m_gio;
}

void Time::getPhut(){
    return this->m_phut;
}

void Time::getGiay(){
    return this->m_giay;
}

bool Time::laNamNhuan(){
    if (this->m_nam % 400 == 0) return true;
    if (this->m_nam % 4 == 0 && this->m_nam % 100 != 0) return true;
    return false;
}

bool Time::ngayHopLe(){
    bool result = true;
    switch (this->m_thang)
    {
    case 1, 3, 5, 7, 8, 10, 12:
        if (this->m_ngay <= 0 || this->m_ngay >= 31) result = false;
        break;
    case 4, 6, 9, 11:
        if (this->m_ngay >=30 || this->m_ngay <= 0) result = false;
    default:
        if (this->laNamNhuan()){
            if (this->m_ngay != 29) result = false;
        } 
        else
        {
            if (this->m_ngay != 28) result = false;
        }
        
    }
    return result;
}

Time& Time::operator=(const Time& thoiGian){
    this->m_ngay = thoiGian.m_ngay;
    this->m_thang = thoiGian.m_thang;
    this->m_nam = thoiGian.m_nam;
    this->m_gio = thoiGian.m_gio;
    this->m_phut = thoiGian.m_phut;
    this->m_giay = thoiGian.m_giay;
    return this;
}

void Time::~Time(){}