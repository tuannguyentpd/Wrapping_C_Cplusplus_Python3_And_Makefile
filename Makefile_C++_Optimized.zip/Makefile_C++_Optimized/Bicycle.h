#ifndef __VEHICLE_H__
#define __VEHICLE_H__
#include "Vehicle.h"
#endif

#ifndef __BICYCLE_H__
#define __BICYCLE_H__

class Bicycle{
};

#endif