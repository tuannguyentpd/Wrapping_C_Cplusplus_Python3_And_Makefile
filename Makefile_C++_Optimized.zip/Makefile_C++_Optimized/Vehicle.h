#ifndef __STRING_H__
#include <string>
#endif

#ifndef __TIME_H__
#include "Time.h"
#endif

#ifndef __VEHICLE_H__
#define __VEHICLE_H__
#endif

class Vehicle{
    private:
        int m_ID;
        std::string m_loaiXe;
        std::string m_chuSoHuu;
        Time m_thoiGianGui;
        Time m_thoiGianTra;
        double m_giaGui; //Tinh theo gio
        double m_giamGia; //Tinh theo don vi phan tram

    public:
        Vehicle();

        void setID(int ID);
        void setLoaiXe(std::string loaiXe);
        void setChuSoHuu(std::string chuSoHuu);
        void setThoiGianGui(Time thoiGianGui);
        void setThoiGianTra(Time thoiGianTra);
        void setGiaGui(double giaGui);
        void setGiamGia(double giamGia);

        int getID();
        std::string getLoaiXe();
        std::string getChuSoHuu();
        Time getThoiGianGui();
        Time getThoiGianTra();
        double getGiaGui();
        double getGiamGia();

        double tinhSoGioGuiXe();
        double tinhTienGuiXe();

        ~Vehicle();
};