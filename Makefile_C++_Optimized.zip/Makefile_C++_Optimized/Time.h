#ifndef __IOSTREAM_H__
#include <iostream>
#endif

#ifndef __TIME_H__
#define __TIME_H__

class Time{
    private:
        int m_ngay;
        int m_thang;
        int m_nam;
        int m_gio; //24h
        int m_phut;
        int m_giay;

    public:
        Time();
        Time(const Time &thoiGian);

        void setNgay(int ngay);
        void setThang(int thang);
        void setNam(int nam);
        void setGio(int gio);
        void setPhut(int phut);
        void setGiay(int giay);

        void getNgay();
        void getThang();
        void getNam();
        void getGio();
        void getPhut();
        void getGiay();

        bool laNamNhuan();
        bool ngayHopLe();

        Time& operator=(const Time& thoiGian);

        ~Time();
};

#endif