#include "Vehicle.h"

Vehicle::Vehicle(){
    this->m_ID = 0;
    this->m_loaiXe = "Xe may";
    this->m_chuSoHuu = "abc";
    this->m_thoiGianGui = new Time();
    this->m_thoiGianTra = new Time();
    this->m_giaGui = 2000.0;
    this->m_giamGia = 0.0;
}

void Vehicle::setID(int ID){
    this->m_ID = ID;
}

void Vehicle::setLoaiXe(std::string loaiXe){
    this->m_loaiXe = loaiXe;
}

void Vehicle::setChuSoHuu(std::string chuSoHuu){
    this->m_chuSoHuu = chuSoHuu;
}

void Vehicle::setThoiGianGui(Time thoiGianGui){
    this->m_thoiGianGui = thoiGianGui;
}

void Vehicle::setThoiGianTra(Time thoiGianTra){
    this->m_thoiGianTra = thoiGianTra;
}

void Vehicle::setGiaGui(double giaGui){
    this->m_giaGui = giaGui;
}

void Vehicle::setGiamGia(double giamGia){
    this->m_giamGia = giamGia;
}

int Vehicle::getID(){
    return this->m_ID;
}

std::string Vehicle::getLoaiXe(){
    return this->m_loaiXe;
}

std::string Vehicle::getChuSoHuu(){
    return this->m_chuSoHuu;
}

Time Vehicle::getThoiGianGui(){
    return this->m_thoiGianGui;
}

Time Vehicle::getThoiGianTra(){
    return this->m_thoiGianTra;
}

double Vehicle::getGiaGui(){
    return this->m_giaGui;
}

double Vehicle::getGiamGia(){
    return this->m_giamGia;
}

double Vehicle::tinhSoGioGuiXe(){}

double Vehicle::tinhTienGuiXe(){
    double result = this->tinhSoGioGuiXe()*this->m_giaGui;
    return result - result*(this->m_giamGia/100.0);
}

Vehicle::~Vehicle(){}