#include"allocal.h"

int* allocal_array(int *a, int n){
    if (a == NULL){
        a = (int *)malloc(n*sizeof(int));
    }
    return a;
}

void free_array(int *a){
    free(a);
}
