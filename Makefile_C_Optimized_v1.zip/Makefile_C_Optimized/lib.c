#include "lib.h"

int findMax_array(int *a, int n){
    if (n<1) return -1;
    int max_index = 0;
    for (int i=0;i<n;++i){
        if (a[i] > a[max_index]) max_index = i;
    }
    return max_index;
}

int findMin_array(int *a, int n){
    if (n<1) return -1;
    int min_index = 0;
    for (int i=0;i<n;++i){
        if (a[i]<a[min_index]) min_index=i;
    }
    return min_index;
}