#include "generateArray.h"

void generate_array(int *a, int n){
    srand(time(NULL));
    for (int i=0;i<n;++i){
        a[i] = rand() % MAX_NUMBER;
    }
}