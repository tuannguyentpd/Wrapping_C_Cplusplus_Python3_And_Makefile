#ifndef __STDIO_H__
#define __STDIO_H__
#include <stdio.h>
#endif

#ifndef __ARRAYSUPPORT_H__
#define __ARRAYSUPPORT_H__

void print_array(int *a, int n);

#endif