#ifndef __LIB_H__
#define __LIB_H__

int findMax_array(int *a, int n);
int findMin_array(int *a, int n);

#endif