#ifndef __RANDOM_H__
#define __RANDOM_H__
#include <time.h>
#include <stdlib.h>
#endif

#ifndef __GENERATEARRAY_H__
#define __GENERATEARRAY_H__

#ifndef MAX_NUMBER
#define MAX_NUMBER 1000000
#endif

void generate_array(int *a, int n);

#endif
