#include "lib.h"

void readAndShowImg(std::string fileName){
    cv::Mat image;
    image = cv::imread(fileName, cv::IMREAD_ANYCOLOR);
 
    if(! image.data )
    {
        std::cout << "Could not open or find the image" << std::endl ;
        return;
    }
 
    cv::namedWindow( "Display window", cv::WINDOW_AUTOSIZE );
    cv::imshow( "Display window", image );
 
    cv::waitKey(0);
    cv::destroyAllWindows();
}