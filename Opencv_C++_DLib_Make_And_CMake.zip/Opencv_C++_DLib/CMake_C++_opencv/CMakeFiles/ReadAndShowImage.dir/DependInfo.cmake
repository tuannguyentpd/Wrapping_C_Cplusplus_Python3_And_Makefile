# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "/home/tuan/Desktop/WrappingC_C++_Python/Opencv_C++_DLib/CMake_C++_opencv/lib.cpp" "/home/tuan/Desktop/WrappingC_C++_Python/Opencv_C++_DLib/CMake_C++_opencv/CMakeFiles/ReadAndShowImage.dir/lib.cpp.o"
  "/home/tuan/Desktop/WrappingC_C++_Python/Opencv_C++_DLib/CMake_C++_opencv/main.cpp" "/home/tuan/Desktop/WrappingC_C++_Python/Opencv_C++_DLib/CMake_C++_opencv/CMakeFiles/ReadAndShowImage.dir/main.cpp.o"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "/usr/local/include/opencv4"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
