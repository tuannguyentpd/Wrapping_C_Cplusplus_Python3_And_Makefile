#ifndef __CORE_H__
#include <opencv2/core.hpp>
#endif // !__CORE_H__

#ifndef __OPENCV_H__
#include <opencv2/opencv.hpp>
#endif // !__OPENCV_H__

#ifndef __IOSTREAM_H__
#include <iostream>
#endif // !__IOSTREAM_H__


#ifndef __LIB_H_
#define __LIB_H_

void readAndShowImg(std::string fileName);

#endif // !__LIB_H_