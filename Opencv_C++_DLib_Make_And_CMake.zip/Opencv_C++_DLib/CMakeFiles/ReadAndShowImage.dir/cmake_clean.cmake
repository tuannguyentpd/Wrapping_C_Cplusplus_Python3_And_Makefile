file(REMOVE_RECURSE
  "CMakeFiles/ReadAndShowImage.dir/lib.cpp.o"
  "CMakeFiles/ReadAndShowImage.dir/main.cpp.o"
  "ReadAndShowImage.pdb"
  "ReadAndShowImage"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/ReadAndShowImage.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
