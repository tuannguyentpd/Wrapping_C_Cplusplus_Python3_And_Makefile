#include <iostream>

#include<opencv2/core.hpp>
#include<opencv2/opencv.hpp>

void readAndShowImg(std::string fileName){
    cv::Mat image;
    image = cv::imread(fileName, cv::IMREAD_ANYCOLOR);
    
    if(! image.data )
    {
        std::cout << "Could not open or find the image" << std::endl ;
        return;
    }
 
    cv::namedWindow( "Display window", cv::WINDOW_AUTOSIZE );
    cv::imshow( "Display window", image );
 
    cv::waitKey(0);
    cv::destroyAllWindows();
    //cv::IMREAD_ANYCOLOR
}

int main( int argc, char** argv )
{
    if( argc != 2)
    {
     std::cout <<" Usage: display_image ImageToLoadAndDisplay" << std::endl;
     return -1;
    }

    readAndShowImg(argv[1]);

    return 0;
}