#include "Array/array.h"
#include "Operations/operation.h"

int main(){
    int *a;
    int n = 10;
    int numa = 4675, numb = 34647;
    
    std::cout << numa << " + " << numb << " = " << sum(numa, numb) << std::endl;
    std::cout << numa << " - " << numb << " = " << minus(numa, numb) << std::endl;
    std::cout << numa << " * " << numb << " = " << multi(numa, numb) << std::endl;
    std::cout << numa << " / " << numb << " = " << div_(numa, numb) << std::endl;
    std::cout << numa << " % " << numb << " = " << mod(numa, numb) << std::endl;

    a = new int[n];
    randomArray(a, n);
    printArray(a, n);

    std::cout << "Sum array is: " << sumArray(a, n) << std::endl;
    std::cout << "Max array is: " << a[findMaxArray(a, n)] << std::endl;
    std::cout << "Min array is: " << a[findMinArray(a, n)] << std::endl;

    delete[] a;
}