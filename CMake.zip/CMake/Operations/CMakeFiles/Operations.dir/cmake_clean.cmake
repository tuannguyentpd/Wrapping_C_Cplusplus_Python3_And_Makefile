file(REMOVE_RECURSE
  "CMakeFiles/Operations.dir/operation.cpp.o"
  "libOperations.pdb"
  "libOperations.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/Operations.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
