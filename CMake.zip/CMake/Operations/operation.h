#ifndef __IOSTREAM_H__
#include <iostream>
#endif // !__IOSTREAM_H__

#ifndef __OPERATION_H__
#define __OPERATION_H__

int sum(int a, int b);
int minus(int a, int b);
int multi(int a, int b);
int div_(int a, int b);
int mod(int a, int b);

#endif // !__OPERATION_H__