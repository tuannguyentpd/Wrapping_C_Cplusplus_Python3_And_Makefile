#include "operation.h"

int sum(int a, int b){
    return a+b;
}

int minus(int a, int b){
    return a-b;
}

int multi(int a, int b){
    return a*b;
}

int div_(int a, int b){
    if (b==0) return 0;
    return a/b;
}

int mod(int a, int b){
    return a%b;
}