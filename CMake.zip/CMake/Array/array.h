#ifndef __IOSTREAM_H__
#include <iostream>
#endif // !__IOSTREAM_H__

#ifndef __TIME_H__
#include <ctime>
#endif // !__TIME_H__

#ifndef __STDLIB_H__
#include <stdlib.h>
#endif // !__STDLIB_H__


#ifndef __ARRAY_H__
#define __ARRAY_H__

#define MAX_RAND_NUM 100000

int randomArray(int *a, int n);
int sumArray(int *a, int n);
int findMaxArray(int *a, int n);
int findMinArray(int *a, int n);
void printArray(int *a, int n);

#endif // !__ARRAY_H__
