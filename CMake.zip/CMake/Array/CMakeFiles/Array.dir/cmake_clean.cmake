file(REMOVE_RECURSE
  "CMakeFiles/Array.dir/array.cpp.o"
  "libArray.pdb"
  "libArray.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/Array.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
