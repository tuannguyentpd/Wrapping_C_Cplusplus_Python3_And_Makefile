#include "array.h"

int randomArray(int *a, int n){
    srand(time(NULL));
    for (int i=0;i<n;++i){
        a[i] = rand() % MAX_RAND_NUM;
    }
}

int sumArray(int *a, int n){
    int sum = 0;
    for (int i=0;i<n;++i){
        sum += a[i];
    }
    return sum;
}

int findMaxArray(int *a, int n){
    if (n==0) return -1;
    if (n==1) return 0;

    int index_res = 0;
    for (int i=1;i<n;++i){
        if (a[i] > a[index_res]){
            index_res = i;
        }
    }

    return index_res;
}

int findMinArray(int *a, int n){
    if (n==0) return -1;
    if (n==1) return 0;

    int index_res = 0;
    for (int i=1;i<n;++i){
        if (a[i] < a[index_res]){
            index_res = i;
        }
    }

    return index_res;
}

void printArray(int *a, int n){
    std::cout << "Array data:" << std::endl;
    for (int i=0;i<n;++i){
        std::cout << a[i] << "\t";
    }
    std::cout << std::endl;
}